import numpy as np 
import numpy.polynomial.polynomial as poly
import numpy.linalg as LA
import matplotlib.pyplot as plt 
from matplotlib import ticker, cm
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
from matplotlib.colors import LogNorm
import scipy.integrate as integrate 
import scipy.optimize as opt
import h5py 

# Matplotlib default param
plt.rcParams['font.size'] = 12
plt.rcParams['legend.fontsize'] = 12
plt.rcParams['legend.loc'] = 'best'
plt.rcParams['lines.linewidth'] = 1.2
plt.rcParams['lines.markersize'] = 0.7
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['font.family'] = 'STIXGeneral'

# Global parameters
gg = 5./3. 
gg1 = gg/(gg - 1.)
gc = 4./3. 
gc1 = gc/(gc - 1.)

def plotdefault():
  plt.rcParams.update(plt.rcParamsDefault)
  plt.rcParams['font.size'] = 12
  plt.rcParams['legend.fontsize'] = 12
  plt.rcParams['legend.loc'] = 'best'
  plt.rcParams['lines.linewidth'] = 1.5
  plt.rcParams['lines.markersize'] = 2.
  plt.rcParams['mathtext.fontset'] = 'stix'
  plt.rcParams['font.family'] = 'STIXGeneral'
  return

def latexify(columns=2, square=False, num_fig=0):
  """
  Set up matplotlib's RC params for LaTeX plotting.
  Call this before plotting a figure.
  Parameters
  ----------
  columns : {1, 2}
  """
  assert(columns in [1, 2])

  fig_width_pt = 240.0 if (columns == 1) else 504.0
  inches_per_pt = 1./72.27 # Convert pt to inch
  golden_mean = (np.sqrt(5.) - 1.)/2. 
  square_size = 1.
  fig_width = fig_width_pt*inches_per_pt # Width in inches
  fig_height = fig_width*golden_mean
  if square:
    fig_height = fig_width*square_size # Height in inches
  if num_fig != 0:
    fig_height = fig_width/num_fig
  fig_size = [fig_width, fig_height]

  font_size = 10 if columns == 1 else 8

  plt.rcParams['pdf.fonttype'] = 42
  plt.rcParams['ps.fonttype'] = 42
  plt.rcParams['font.size'] = font_size
  plt.rcParams['axes.labelsize'] = font_size
  plt.rcParams['axes.titlesize'] = font_size
  plt.rcParams['xtick.labelsize'] = font_size
  plt.rcParams['ytick.labelsize'] = font_size
  plt.rcParams['legend.fontsize'] = font_size
  plt.rcParams['figure.figsize'] = fig_size
  plt.rcParams['figure.titlesize'] = 12
  return 



class Profile:
  def __init__(self, alpha0, betac0, etaH, chi0, rho0=1., T0=1., g0=1., nu=3, taper=0.5): 
    self.alpha0 = alpha0 
    self.betac0 = betac0 
    self.etaH = etaH
    self.chi0 = chi0

    self.rho0 = rho0
    self.T0 = T0 
    self.g0 = g0
    self.pg0 = rho0*T0 
    self.pc0 = alpha0*self.pg0 
    self.H = T0/g0 
    self.a = taper*self.H 
    self.nu = nu

    self.rhoH = self.Rho(self.H)
    self.pgH = self.rhoH*T0
    self.pcH = self.pc0*(self.rhoH/rho0)**(gc/(gc + 2.))
    self.alphaH = self.pcH/self.pgH 
    self.BH = np.sqrt(2.*self.pcH/betac0)
    self.vaH = self.BH/np.sqrt(self.rhoH)
    self.betaH = 2.*self.pgH/self.BH**2

    self.LcH = ((gc + 2.)/gc)*(T0 + gc*(1. - 1./betac0)*self.pcH/((gc + 2.)*self.rhoH))/self.G(self.H)
    self.cs = np.sqrt(gg*T0)
    # self.kappa = etaH*gc*self.cs*self.LcH 
    self.kappa = etaH*gc*(gc - 1.)*self.LcH*self.vaH

    self.gH = self.G(self.H)
    self.LH = self.L(self.H)
    self.tcoolH = self.tcool(self.H)
    self.tffH = self.tff(self.H)
    self.deltaH = self.tcoolH/self.tffH 

    self.run_athena = False

    # End initialization

  def G(self, x):
    g0 = self.g0 
    a = self.a 
    nu = self.nu
    x1 = np.abs(x) if x < 0 else x
    g = g0*(x1/a)**nu/(1. + (x1/a)**nu) 
    g = -g if x < 0 else g
    return g

  def Rho(self, x):
    g0 = self.g0
    rho0 = self.rho0  
    a = self.a 
    H = self.H
    alpha0 = self.alpha0 
    betac0 = self.betac0
    nu = self.nu
    x1 = np.abs(x) if x < 0 else x

    g_func = lambda u: g0*(u/a)**nu/((u/a)**nu + 1.)

    upper_lim = 1.1*rho0 
    lower_lim = rho0*np.exp(-x1/H)

    func = lambda rho: np.log(rho/rho0) \
      + (0.5*gc*(1. - 1./betac0)*alpha0/rho0)*(1. - (rho/rho0)**(-2./(gc + 2.))) \
      + integrate.quad(g_func, 0., x1)[0]/T0

    root = opt.brentq(func, lower_lim, upper_lim)
    return root

  def Drhodx(self, x):
    T0 = self.T0 
    betac0 = self.betac0
    rho = self.Rho(x)
    pc = self.Pc(x)
    drhodx = -rho*self.G(x)/(T0 + (gc/(gc + 2.))*(1. - 1./betac0)*pc/rho)
    return drhodx

  def Pg(self, x):
    T0 = self.T0 
    pg = self.Rho(x)*T0 
    return pg 

  def B(self, x):
    betac0 = self.betac0 
    pc = self.Pc(x)
    b = np.sqrt(2.*pc/betac0)
    return b 

  def Dbdx(self, x):
    betac0 = self.betac0 
    b = self.B(x)
    dpcdx = self.Dpcdx(x)
    dbdx = dpcdx/(betac0*b)
    return dbdx

  def Dpgdx(self, x):
    T0 = self.T0 
    dpgdx = T0*self.Drhodx(x)
    return dpgdx 

  def Pc(self, x):
    pc0 = self.pc0 
    rho0 = self.rho0 
    pc = pc0*(self.Rho(x)/rho0)**(gc/(gc + 2.))
    return pc 

  def Dpcdx(self, x):
    T0 = self.T0 
    a = self.a
    betac0 = self.betac0
    rho = self.Rho(x)
    pc = self.Pc(x)
    dpcdx = -(gc/(gc + 2.))*pc*self.G(x)/(T0 + (gc/(gc + 2.))*(1. - 1./betac0)*pc/rho)
    return dpcdx

  def D2pcdx2(self, x):
    T0 = self.T0
    a = self.a
    nu = self.nu
    betac0 = self.betac0
    x1 = np.abs(x) if x < 0 else x
    rho = self.Rho(x1)
    pc = self.Pc(x1)
    drhodx = self.Drhodx(x1)
    dpcdx = self.Dpcdx(x1)
    g = self.G(x1)
    dgdx = (nu/a)*(x1/a)**(nu - 1)/((x1/a)**nu + 1.)**2 

    term1 = rho*g*((gc/(gc + 2.))*(1. - 1./betac0)*dpcdx/rho - (gc/(gc + 2.))*(1. - 1./betac0)*pc*drhodx/rho**2)
    term2 = (g*drhodx + rho*dgdx)*(T0 + (gc/(gc + 2.))*(1. - 1./betac0)*pc/rho)
    term3 = (T0 + (gc/(gc + 2.))*(1. - 1./betac0)*pc/rho)**2

    d2rhodx2 = (term1 - term2)/term3
    d2pcdx2 = ((gc/(gc + 2.))*pc/rho)*d2rhodx2 + ((gc/(gc + 2.))/rho)*drhodx*dpcdx - ((gc/(gc + 2.))*pc/rho**2)*drhodx**2

    return d2pcdx2

  def Fc(self, x):
    b = self.B(x) 
    kappa = self.kappa 
    dpcdx = self.Dpcdx(x)
    va = b/np.sqrt(self.Rho(x))
    vs = -va*np.sign(dpcdx)
    fc = gc1*self.Pc(x)*vs - (kappa/(gc - 1.))*dpcdx
    return fc

  def Q(self, x):
    kappa = self.kappa
    q = -(kappa/(gc - 1.))*self.D2pcdx2(x)
    return q 

  def L(self, x):
    chi0 = self.chi0
    b = self.B(x) 
    va = b/np.sqrt(self.Rho(x))
    dpcdx = self.Dpcdx(x)
    vs = -va*np.sign(dpcdx)
    rho = self.Rho(x)
    Lx = -vs*dpcdx/(chi0*rho**2)
    return Lx

  def tcool(self, x):
    T0 = self.T0 
    L = self.L(x)
    rho = self.Rho(x)
    tc = (T0/(gg - 1.))/(rho*L)
    return tc

  def tff(self, x):
    # if x < 0: 
    #   x = np.abs(x)
    # a = self.a
    # nu = self.nu
    # g0 = self.g0
    # f = lambda t, y: np.array([y[1], -g0*(y[0]/a)**nu/(1. + (y[0]/a)**nu)])
    # h = lambda t, y: y[0]
    # h.terminal = True
    # h.direction = -1
    # sol = integrate.solve_ivp(f, [0, 1000.], [x, 0.], events=h)
    # return sol.t_events[0][0]
    free_fall_time = np.sqrt(2*x/self.G(x))
    return free_fall_time

  def athena(self, xmin, xmax, meshgrid, nghost=2): 
    self.run_athena = True
    chi0 = self.chi0
    rho0 = self.rho0
    T0 = self.T0
    pc0 = self.pc0
    kappa = self.kappa

    dx = (xmax - xmin)/meshgrid
    xv_mesh = np.zeros(meshgrid)
    xvghost_mesh = np.zeros(meshgrid+2*nghost)
    xf_mesh = np.zeros(meshgrid+1)
    xfghost_mesh = np.zeros(meshgrid+2*nghost+1)
    rho_mesh = np.zeros(meshgrid)
    fc_mesh = np.zeros(meshgrid)
    g_mesh = np.zeros(meshgrid)
    q_mesh = np.zeros(meshgrid)
    L_mesh = np.zeros(meshgrid)
    heat_mesh = np.zeros(meshgrid)
    bccx_mesh = np.zeros(meshgrid)
    bx_mesh = np.zeros(meshgrid+2*nghost+1)
    tcool_mesh = np.zeros(meshgrid)
    tff_mesh = np.zeros(meshgrid)
    qv_mesh = np.zeros(meshgrid+2*nghost)
    qf_mesh = np.zeros(meshgrid+2*nghost+1)
    dpgdx_mesh = np.zeros(meshgrid)
    dpcdx_mesh = np.zeros(meshgrid)
    rho_xinner_bval = np.zeros(nghost)
    rho_xouter_bval = np.zeros(nghost)
    pg_xinner_bval = np.zeros(nghost)
    pg_xouter_bval = np.zeros(nghost)
    pc_xinner_bval = np.zeros(nghost)
    pc_xouter_bval = np.zeros(nghost)
    fc_xinner_bval = np.zeros(nghost)
    fc_xouter_bval = np.zeros(nghost)
    for i in range(meshgrid):
      xv_mesh[i] = xmin + (i + 0.5)*dx
      rho_mesh[i] = self.Rho(xv_mesh[i])
      fc_mesh[i] = self.Fc(xv_mesh[i])
      g_mesh[i] = self.G(xv_mesh[i])
      q_mesh[i] = self.Q(xv_mesh[i])
      L_mesh[i] = self.L(xv_mesh[i])
      bccx_mesh[i] = self.B(xv_mesh[i])
      tcool_mesh[i] = self.tcool(xv_mesh[i])
      tff_mesh[i] = self.tff(xv_mesh[i])
      dpgdx_mesh[i] = self.Dpgdx(xv_mesh[i])
      dpcdx_mesh[i] = self.Dpcdx(xv_mesh[i])
    for i in range(meshgrid+1):
      xf_mesh[i] = xmin + i*dx 
    for i in range(meshgrid+2*nghost):
      xvghost_mesh[i] = xmin + (i - 1.5)*dx
      qv_mesh[i] = self.Q(xvghost_mesh[i])
    for i in range(meshgrid+2*nghost+1):
      xfghost_mesh[i] = xmin + (i - 2)*dx
      qf_mesh[i] = self.Q(xfghost_mesh[i])
      bx_mesh[i] = self.B(xfghost_mesh[i])
    for i in range(nghost):
      xinner = xmin - (i + 0.5)*dx 
      xouter = xmax + (i + 0.5)*dx
      rho_xinner_bval[i] = self.Rho(xinner)
      rho_xouter_bval[i] = self.Rho(xouter)
      pg_xinner_bval[i] = self.Pg(xinner)
      pg_xouter_bval[i] = self.Pg(xouter)
      pc_xinner_bval[i] = self.Pc(xinner)
      pc_xouter_bval[i] = self.Pc(xouter)
      fc_xinner_bval[i] = self.Fc(xinner)
      fc_xouter_bval[i] = self.Fc(xouter)

    heat_mesh = (1. - chi0)*rho_mesh**2*L_mesh

    pg_mesh = rho_mesh*T0
    pc_mesh = pc0*(rho_mesh/rho0)**(gc/(gc + 2.))
    vs_mesh = -(bccx_mesh/np.sqrt(rho_mesh))*np.sign(dpcdx_mesh)

    cs_mesh = np.sqrt(gg*pg_mesh/rho_mesh)
    cc_mesh = np.sqrt(gc*pc_mesh/rho_mesh)
    va_mesh = bccx_mesh/np.sqrt(rho_mesh)
    alpha_mesh = pc_mesh/pg_mesh
    beta_mesh = 2.*pg_mesh/bccx_mesh**2
    eta_mesh = kappa/(gc*cs_mesh*np.abs(pc_mesh/dpcdx_mesh))
    delta_mesh = tcool_mesh/tff_mesh

    self.xmin = xmin
    self.xmax = xmax
    self.meshgrid = meshgrid
    self.dx = dx 
    self.xv_mesh = xv_mesh
    self.xvghost_mesh = xvghost_mesh
    self.xf_mesh = xf_mesh
    self.xfghost_mesh = xfghost_mesh
    self.rho_mesh = rho_mesh 
    self.pg_mesh = pg_mesh
    self.pc_mesh = pc_mesh
    self.fc_mesh = fc_mesh 
    self.g_mesh = g_mesh
    self.q_mesh = q_mesh
    self.L_mesh = L_mesh
    self.heat_mesh = heat_mesh
    self.bccx_mesh = bccx_mesh
    self.bx_mesh = bx_mesh
    self.tcool_mesh = tcool_mesh
    self.tff_mesh = tff_mesh
    self.qv_mesh = qv_mesh
    self.qf_mesh = qf_mesh
    self.dpgdx_mesh = dpgdx_mesh
    self.dpcdx_mesh = dpcdx_mesh
    self.rho_xinner_bval = rho_xinner_bval
    self.rho_xouter_bval = rho_xouter_bval
    self.pg_xinner_bval = pg_xinner_bval
    self.pg_xouter_bval = pg_xouter_bval
    self.pc_xinner_bval = pc_xinner_bval
    self.pc_xouter_bval = pc_xouter_bval
    self.fc_xinner_bval = fc_xinner_bval
    self.fc_xouter_bval = fc_xouter_bval
    self.Lc = np.abs(pc_mesh/dpcdx_mesh)
    self.vs_mesh = vs_mesh
    self.va_mesh = va_mesh
    self.cs_mesh = cs_mesh
    self.cc_mesh = cc_mesh
    self.alpha_mesh = alpha_mesh
    self.beta_mesh = beta_mesh
    self.eta_mesh = eta_mesh 
    self.delta_mesh = delta_mesh
    self.c_min = np.amax([2.*np.pi*self.kappa/dx, np.amax(va_mesh), np.amax(cs_mesh), np.amax(cc_mesh)])

    return 

  def seeding(self, amp, mode_min, mode_max, min_lims, max_lims, grid=(1, 1, 256)):
    if not self.run_athena:
      raise ValueError('### Need to run athena function first ###')

    if (amp <= 0.):
      self.dd = np.zeros(grid)
      return

    Lx = max_lims[2] - min_lims[2]
    dx = Lx/grid[2]
    total_mode = mode_max - mode_min + 1
    if (grid[1] > 1):
      Ly = max_lims[1] - min_lims[1]
      dy = Ly/grid[1]
      total_mode *= (mode_max - mode_min + 1)
    if (grid[0] > 1):
      Lz = max_lims[0] - min_lims[0]
      dz = Lz/grid[0]
      total_mode *= (mode_max - mode_min + 1)

    x_mesh = np.zeros(grid[2])
    y_mesh = np.zeros(grid[1])
    z_mesh = np.zeros(grid[0])
    for i in np.arange(grid[2]):
      x_mesh[i] = min_lims[2] + (i + 0.5)*dx 
    if (grid[1] > 1):
      for j in np.arange(grid[1]):
        y_mesh[j] = min_lims[1] + (j + 0.5)*dy 
    if (grid[0] > 1):
      for k in np.arange(grid[0]):
        z_mesh[k] = min_lims[0] + (k + 0.5)*dz 

    dd = np.zeros(grid)

    z_meshgrid, y_meshgrid, x_meshgrid = np.meshgrid(z_mesh, y_mesh, x_mesh, indexing='ij')
    amp_mode = np.abs(np.random.normal(0., amp, total_mode))
    phasex_mode = np.random.uniform(0., 2.*np.pi, total_mode)
    if (grid[1] > 1):
      phasey_mode = np.random.uniform(0., 2.*np.pi, total_mode)
    if (grid[0] > 1):
      phasez_mode = np.random.uniform(0., 2.*np.pi, total_mode)

    if (grid[0] > 1):
      for l in np.arange(0, mode_max - mode_min + 1):
        for m in np.arange(0, mode_max - mode_min + 1):
          for n in np.arange(0, mode_max - mode_min + 1):
            l_now = mode_min + l 
            m_now = mode_min + m 
            n_now = mode_min + n
            shift = l*(mode_max - mode_min + 1)**2 + m*(mode_max - mode_min + 1) + n
            dd += (amp_mode[shift]/np.sqrt(total_mode)) \
              *np.sin(2.*np.pi*n_now*x_meshgrid + phasex_mode[shift]) \
              *np.sin(2.*np.pi*m_mow*y_meshgrid + phasey_mode[shift]) \
              *np.sin(2.*np.pi*l_now*z_meshgrid + phasez_mode[shift]) 
    elif (grid[1] > 1):
      for m in np.arange(0, mode_max - mode_min + 1):
        for n in np.arange(0, mode_max - mode_min + 1):
          m_now = mode_min + m 
          n_now = mode_min + n 
          shift = m*(mode_max - mode_min + 1) + n
          dd += (amp_mode[shift]/np.sqrt(total_mode)) \
            *np.sin(2.*np.pi*n_now*x_meshgrid + phasex_mode[shift]) \
            *np.sin(2.*np.pi*m_now*y_meshgrid + phasey_mode[shift])
    else:
      for n in np.arange(0, mode_max - mode_min + 1):
        n_now = mode_min + n
        shift = n 
        dd += (amp_mode[shift]/np.sqrt(total_mode)) \
          *np.sin(2.*np.pi*n_now*x_meshgrid + phasex_mode[shift])

    self.dd = dd

    return



# End of class Profile



# For stability analysis of 1d CRMHD equations
# All frequencies/rates are normalized w.r.t. the sound frequency
class TwoMomentStability:
  def __init__(self, nua, nuc, nud, nums, numd, numtot, va, cc, c):
    self.nua = nua 
    self.nuc = nuc 
    self.nud = nud 
    self.nums = nums 
    self.numd = numd
    self.numtot = numtot
    self.va = va 
    self.cc = cc 
    self.c = c

  # Calculate mode frequencies including kL contributions
  def modes(self, kL): 
    nua = self.nua 
    nuc = self.nuc 
    nud = self.nud 
    nums = self.nums 
    numd = self.numd 
    numtot = self.numtot 
    va = self.va 
    cc = self.cc 
    c = self.c

    term01 = gc*nua - 1j*nud
    p0 = 0.5*(gg - 1.)*nua**2*nuc**2 - 1j*0.5*(gg - 1.)*nuc**2*nua*term01/(gc*kL)

    term11 = nua - 1j*nud 
    term12 = (gg - 1.5)*nua + 1j*0.5*(gg - 1.)*nua**2/((gc - 1.)*nums)
    term13 = (gc*gg - 0.5*gg - 1.5*gc)*nua + 1j*nud + 1j*0.5*gc*(gg - 1.)*nua**2/((gc - 1.)*numd) \
      + 0.5*(gg - 1.)*nua*nud/((gc - 1.)*numd)
    p1 = term11 - nuc**2*term12 + 1j*nuc**2*term13/(gc*kL) - 0.5*gc*(gg - 1.)*cc**2*nua**3/((gc - 1.)*c**2)

    term21 = 1. - 1j*nua/nums - gc*va**2/c**2 + (1j*nua + nud)/((gc - 1.)*numtot)
    term22 = 1. - 1j*(gg - 1.5)*nua/((gc - 1.)*nums)
    term23 = gc + 1j*(3*gc - 2.*gg*gc + 1.)*nua/(2*(gc - 1.)*numd) \
      + gc*(0.5 - gg)*va**2/c**2 + nud/((gc - 1.)*numd)
    term24 = (2*gc*(gg - 1.) + 0.5*(1. - 3.*gg))*nua**2 + 1j*(gg - 0.5)*nua*nud 
    p2 = -term21 - nuc**2*term22 + 1j*nuc**2*term23/(gc*kL) + cc**2*term24/((gc - 1.)*c**2)

    term31 = 2. - 1j*nua/nums - gc*va**2/c**2 
    term32 = 1j*gc*(gg - 1.5)*va**2/((gc - 1.)*c**2*numd) - 1j*(gc + 1.)/((gc - 1.)*numd) \
      - gc*cc**2*nua/(c**2*nuc**2) - 0.5*(gg - 1.)*nua/((gc - 1.)*numd)**2
    term33 = (gg + 2*gc - 1.5)*nua \
      - 1j*(gg - 0.5)*nua**2/nums - 1j*(gg*gc - 0.5*gg - 0.5*gc)*nua**2/((gc - 1.)*numd) \
      + 1j*nud - gc*(gg - 0.5)*nua*va**2/c**2
    p3 = -nua + 1j*nud + 1j*nuc**2/((gc - 1.)*nums) \
      + 1j*term31/((gc - 1.)*numtot) + 1j*nuc**2*term32/(gc*kL) + cc**2*term33/((gc - 1.)*c**2)

    term41 = -nua + 1j*nud + 1j/((gc - 1.)*numtot)
    term42 = 1. - 1j*(gc + gg - 1.5)*nua/((gc - 1.)*numtot) - 1j*nua/((gc - 1.)*numd) \
      - gc*va**2/c**2 - nua/(kL*numd)
    p4 = 1. - 1j*nua/nums - gc*va**2/c**2 - 1j*term41/((gc - 1.)*numtot) \
      + cc**2*term42/((gc - 1.)*c**2) - 1j*nuc**2/(gc*(gc - 1.)**2*kL*numd**2)

    term51 = 2. - 1j*nua/nums - gc*va**2/c**2 + cc**2/((gc - 1.)*c**2)
    p5 = -1j*term51/((gc - 1.)*numtot)

    p6 = -1./((gc - 1.)*numtot)**2

    p = [p0, p1, p2, p3, p4, p5, p6]

    roots = poly.polyroots(p)

    self.roots = roots 
    return

  def perturb(self, nu):
    nua = self.nua 
    nuc = self.nuc 
    nud = self.nud 
    nums = self.nums 
    numd = self.numd 
    numtot = self.numtot 
    va = self.va 
    cc = self.cc 
    c = self.c

    rterm0 = np.array([0.5*(gg - 1.)*nua**2*nuc**2], dtype=complex)
    rterm1 = nu*np.array([nua, -1j*nud, -(gg - 1.5)*nuc**2*nua, \
      -1j*0.5*(gg - 1.)*nuc**2*nua**2/((gc - 1.)*nums), -0.5*gc*(gg - 1.)*cc**2*nua**3/((gc - 1.)*c**2)], dtype=complex)
    rterm2 = nu**2*np.array([-1., 1j*nua/nums, gc*va**2/c**2, -1j*nua/((gc - 1.)*numtot), -nud/((gc - 1.)*numtot), \
      -nuc**2, 1j*(gg - 1.5)*nuc**2*nua/((gc - 1.)*nums), \
      (2.*gc*(gg - 1.) + 0.5*(1. - 3.*gg))*nua**2*cc**2/((gc - 1.)*c**2), 1j*(gg - 0.5)*nua*nud*cc**2/((gc - 1.)*c**2)], dtype=complex)
    rterm3 = nu**3*np.array([-nua, 1j*nud, 1j*nuc**2/((gc - 1.)*nums), \
      2.*1j/((gc - 1.)*numtot), nua/((gc - 1.)*numtot*nums), -1j*gc*va**2/((gc - 1.)*numtot*c**2), \
      (gg + 2.*gc - 1.5)*nua*cc**2/((gc - 1.)*c**2), -1j*(gg - 0.5)*nua**2*cc**2/((gc - 1.)*nums*c**2), \
      -1j*(gg*gc - 0.5*gg - 0.5*gc)*nua**2*cc**2/((gc - 1.)**2*c**2*numd), 1j*nud*cc**2/((gc - 1.)*c**2), \
      -gc*(gg - 0.5)*nua*va**2*cc**2/((gc - 1.)*c**4)], dtype=complex)
    rterm4 = nu**4*np.array([1., -1j*nua/nums, -gc*va**2/c**2, 1j*nua/((gc - 1.)*numtot), nud/((gc - 1.)*numtot), \
      1./((gc - 1.)*numtot)**2, cc**2/((gc - 1.)*c**2), -1j*(gg + gc - 1.5)*nua*cc**2/((gc - 1.)**2*c**2*numtot), \
      -1j*nua*cc**2/((gc - 1.)**2*c**2*numd), -gc*va**2*cc**2/((gc - 1.)*c**4)], dtype=complex)
    rterm5 = nu**5*np.array([-2.*1j/((gc - 1.)*numtot), -nua/((gc - 1.)*numtot**2), 1j*gc*va**2/((gc - 1.)*numtot*c**2), \
      -1j*cc**2/((gc - 1.)**2*numtot*c**2)], dtype=complex)
    rterm6 = nu**6*np.array([-1./((gc - 1.)*numtot)**2], dtype=complex)

    iterm0 = -np.array([nua, -1j*nud, -(gg - 1.5)*nuc**2*nua, \
      -1j*0.5*(gg - 1.)*nuc**2*nua**2/((gc - 1.)*nums), -0.5*gc*(gg - 1.)*cc**2*nua**3/((gc - 1.)*c**2)], dtype=complex)
    iterm1 = -2.*nu*np.array([-1., 1j*nua/nums, gc*va**2/c**2, -1j*nua/((gc - 1.)*numtot), -nud/((gc - 1.)*numtot), \
      -nuc**2, 1j*(gg - 1.5)*nuc**2*nua/((gc - 1.)*nums), \
      (2.*gc*(gg - 1.) + 0.5*(1. - 3.*gg))*nua**2*cc**2/((gc - 1.)*c**2), 1j*(gg - 0.5)*nua*nud*cc**2/((gc - 1.)*c**2)], dtype=complex)
    iterm2 = -3.*nu**2*np.array([-nua, 1j*nud, 1j*nuc**2/((gc - 1.)*nums), \
      2.*1j/((gc - 1.)*numtot), nua/((gc - 1.)*numtot*nums), -1j*gc*va**2/((gc - 1.)*numtot*c**2), \
      (gg + 2.*gc - 1.5)*nua*cc**2/((gc - 1.)*c**2), -1j*(gg - 0.5)*nua**2*cc**2/((gc - 1.)*nums*c**2), \
      -1j*(gg*gc - 0.5*gg - 0.5*gc)*nua**2*cc**2/((gc - 1.)**2*c**2*numd), 1j*nud*cc**2/((gc - 1.)*c**2), \
      -gc*(gg - 0.5)*nua*va**2*cc**2/((gc - 1.)*c**4)], dtype=complex)
    iterm3 = -4*nu**3*np.array([1., -1j*nua/nums, -gc*va**2/c**2, 1j*nua/((gc - 1.)*numtot), nud/((gc - 1.)*numtot), \
      1./((gc - 1.)*numtot)**2, cc**2/((gc - 1.)*c**2), -1j*(gg + gc - 1.5)*nua*cc**2/((gc - 1.)**2*c**2*numtot), \
      -1j*nua*cc**2/((gc - 1.)**2*c**2*numd), -gc*va**2*cc**2/((gc - 1.)*c**4)], dtype=complex)
    iterm4 = -5.*nu**4*np.array([-2.*1j/((gc - 1.)*numtot), -nua/((gc - 1.)*numtot**2), 1j*gc*va**2/((gc - 1.)*numtot*c**2), \
      -1j*cc**2/((gc - 1.)**2*numtot*c**2)], dtype=complex)
    iterm5 = -6.*nu**5*np.array([-1./((gc - 1.)*numtot)**2], dtype=complex)

    rterm = np.append(rterm0, rterm1)
    rterm = np.append(rterm, rterm2)
    rterm = np.append(rterm, rterm3)
    rterm = np.append(rterm, rterm4)
    rterm = np.append(rterm, rterm5)
    rterm = np.append(rterm, rterm6)

    iterm = np.append(iterm0, iterm1)
    iterm = np.append(iterm, iterm2)
    iterm = np.append(iterm, iterm3)
    iterm = np.append(iterm, iterm4)
    iterm = np.append(iterm, iterm5)

    perturb = np.sum(rterm)/np.sum(iterm)

    self.perturb = perturb
    return

  def order(self, nu):
    nua = self.nua 
    nuc = self.nuc 
    nud = self.nud 
    nums = self.nums 
    numd = self.numd 
    numtot = self.numtot 
    va = self.va 
    cc = self.cc 
    c = self.c

    rterm0 = np.array([nua**2*nuc**2], dtype=complex)
    rterm1 = nu*np.array([nua, 1j*nud, nuc**2*nua, \
      1j*nuc**2*nua**2/nums, cc**2*nua**3/c**2], dtype=complex)
    rterm2 = nu**2*np.array([1., 1j*nua/nums, va**2/c**2, 1j*nua/numtot, nud/numtot, \
      nuc**2, 1j*nuc**2*nua/nums, \
      nua**2*cc**2/c**2, 1j*nua*nud*cc**2/c**2], dtype=complex)
    rterm3 = nu**3*np.array([nua, 1j*nud, 1j*nuc**2/nums, \
      1j/numtot, nua/(numtot*nums), 1j*va**2/(numtot*c**2), \
      nua*cc**2/c**2, 1j*nua**2*cc**2/(nums*c**2), \
      1j*nua**2*cc**2/(c**2*numd), 1j*nud*cc**2/c**2, \
      nua*va**2*cc**2/c**4], dtype=complex)
    rterm4 = nu**4*np.array([1., 1j*nua/nums, va**2/c**2, 1j*nua/numtot, nud/numtot, \
      1./numtot**2, cc**2/c**2, 1j*nua*cc**2/(c**2*numtot), \
      1j*nua*cc**2/(c**2*numd), va**2*cc**2/c**4], dtype=complex)
    rterm5 = nu**5*np.array([1j/numtot, nua/numtot**2, 1j*va**2/(numtot*c**2), \
      1j*cc**2/(numtot*c**2)], dtype=complex)
    rterm6 = nu**6*np.array([1./numtot**2], dtype=complex)

    iterm0 = np.array([nua, 1j*nud, nuc**2*nua, \
      1j*nuc**2*nua**2/nums, cc**2*nua**3/c**2], dtype=complex)
    iterm1 = nu*np.array([1., 1j*nua/nums, va**2/c**2, 1j*nua/numtot, nud/numtot, \
      nuc**2, 1j*nuc**2*nua/nums, \
      nua**2*cc**2/c**2, 1j*nua*nud*cc**2/c**2], dtype=complex)
    iterm2 = nu**2*np.array([nua, 1j*nud, 1j*nuc**2/nums, \
      1j/numtot, nua/(numtot*nums), 1j*va**2/(numtot*c**2), \
      nua*cc**2/c**2, 1j*nua**2*cc**2/(nums*c**2), \
      1j*nua**2*cc**2/(c**2*numd), 1j*nud*cc**2/c**2, \
      nua*va**2*cc**2/c**4], dtype=complex)
    iterm3 = nu**3*np.array([1., 1j*nua/nums, va**2/c**2, 1j*nua/numtot, nud/numtot, \
      1./numtot**2, cc**2/c**2, 1j*nua*cc**2/(c**2*numtot), \
      1j*nua*cc**2/(c**2*numd), va**2*cc**2/c**4], dtype=complex)
    iterm4 = nu**4*np.array([1j/numtot, nua/numtot**2, 1j*va**2/(numtot*c**2), \
      1j*cc**2/(numtot*c**2)], dtype=complex)
    iterm5 = nu**5*np.array([1./numtot**2], dtype=complex)

    rterm = np.append(rterm0, rterm1)
    rterm = np.append(rterm, rterm2)
    rterm = np.append(rterm, rterm3)
    rterm = np.append(rterm, rterm4)
    rterm = np.append(rterm, rterm5)
    rterm = np.append(rterm, rterm6)
    rterm_max = np.amax(np.abs(rterm))
    rterm_norm = rterm_max/np.abs(rterm)
    rterm_sort = np.sort(rterm_norm)
    rterm_argsort = np.argsort(rterm_norm)
    rterm_real = np.real(rterm)
    rterm_imag = np.imag(rterm)
    rterm_real_max = np.amax(np.abs(rterm_real))
    rterm_imag_max = np.amax(np.abs(rterm_imag))
    rterm_real_norm = rterm_real_max/np.abs(rterm_real)
    rterm_imag_norm = rterm_imag_max/np.abs(rterm_imag)
    rterm_real_sort = np.sort(rterm_real_norm)
    rterm_real_argsort = np.argsort(rterm_real_norm)
    rterm_imag_sort = np.sort(rterm_imag_norm)
    rterm_imag_argsort = np.argsort(rterm_imag_norm)

    iterm = np.append(iterm0, iterm1)
    iterm = np.append(iterm, iterm2)
    iterm = np.append(iterm, iterm3)
    iterm = np.append(iterm, iterm4)
    iterm = np.append(iterm, iterm5)
    iterm_max = np.amax(np.abs(iterm))
    iterm_norm = iterm_max/np.abs(iterm)
    iterm_sort = np.sort(iterm_norm)
    iterm_argsort = np.argsort(iterm_norm)
    iterm_real = np.real(iterm)
    iterm_imag = np.imag(iterm)
    iterm_real_max = np.amax(np.abs(iterm_real))
    iterm_imag_max = np.amax(np.abs(iterm_imag))
    iterm_real_norm = iterm_real_max/np.abs(iterm_real)
    iterm_imag_norm = iterm_imag_max/np.abs(iterm_imag)
    iterm_real_sort = np.sort(iterm_real_norm)
    iterm_real_argsort = np.argsort(iterm_real_norm)
    iterm_imag_sort = np.sort(iterm_imag_norm)
    iterm_imag_argsort = np.argsort(iterm_imag_norm)

    self.rterm = rterm 
    self.rterm_sort = rterm_sort
    self.rterm_argsort = rterm_argsort 
    self.rterm_real = rterm_real
    self.rterm_imag = rterm_imag 
    self.rterm_real_norm = rterm_real_norm
    self.rterm_imag_norm = rterm_imag_norm

    self.iterm = iterm 
    self.iterm_sort = iterm_sort
    self.iterm_argsort = iterm_argsort 
    self.iterm_real = iterm_real
    self.iterm_imag = iterm_imag 
    self.iterm_real_norm = iterm_real_norm
    self.iterm_imag_norm = iterm_imag_norm 

    self.rterm_real_sort = rterm_real_sort
    self.rterm_real_argsort = rterm_real_argsort
    self.rterm_imag_sort = rterm_imag_sort 
    self.rterm_imag_argsort = rterm_imag_argsort 

    self.iterm_real_sort = iterm_real_sort
    self.iterm_real_argsort = iterm_real_argsort
    self.iterm_imag_sort = iterm_imag_sort 
    self.iterm_imag_argsort = iterm_imag_argsort 

    return



# 1D linear analysis of thermal stability of flows
class ThermalStability:
  def __init__(self):
    return

  def growth(self, k, rho, drhodx, pg, dpgdx, pc, dpcdx, B, dvadx, kappa, cool, cool_index, g): 
    va = B/np.sqrt(rho)
    cs = np.sqrt(gg*pg/rho)
    alpha = pc/pg 
    wa = k*va 
    ws = k*cs 
    wd = kappa*k**2
    wc = rho**2*cool/pg 
    wff = g/cs 

    dispersion = np.zeros((4, 4), dtype=complex)

    dispersion[0, 1] = k*rho - 1j*drhodx

    dispersion[1, 0] = -1j*wff*cs/rho 
    dispersion[1, 2] = k/rho
    dispersion[1, 3] = k/rho 

    dispersion[2, 0] = 1j*(gg - 1.)*((cool_index - 2)*wc*pg + 0.5*va*dpcdx)/rho
    dispersion[2, 1] = gg*k*pg - dpgdx
    dispersion[2, 2] = -1j*(gg - 1.)*wc*cool_index
    dispersion[2, 3] = (gg - 1.)*wa

    dispersion[3, 0] = 0.5*(1j*va*dpcdx - gc*wa*pc + 1j*gc*pc*dvadx - 1j*gc*pc*va*drhodx/rho)/rho 
    dispersion[3, 1] = gc*k*pc - 1j*dpcdx
    dispersion[3, 3] = wa - 1j*wd - 1j*gc*dvadx

    val, vec = LA.eig(dispersion)

    # Normalize w.r.t. Alfvenic freq
    val /= k*va
    return val



#########################################

if (__name__ == '__main__'):
  alpha0 = 1.
  betac0 = 100.
  etaH = 0.01
  chi0 = 0.20

  rho0 = 1. 
  T0 = 1.
  g0 = 1.
  nu = 3
  taper = 0.3 # Equivalently a in input file

  prob = Profile(alpha0, betac0, etaH, chi0, rho0=rho0, T0=T0, g0=g0, nu=nu, taper=taper)
  prob.athena(-2.*prob.H, 2.*prob.H, 512)
  prob.seeding(0.0, 1, 30, (-0.5, prob.xmin, prob.xmin), (0.5, prob.xmax, prob.xmax), grid=(1, 1, prob.meshgrid))

  plotdefault()

  fig1 = plt.figure()
  fig2 = plt.figure()
  ax1 = fig1.add_subplot(111)
  ax2 = fig2.add_subplot(111)

  ax1.plot(prob.xv_mesh, prob.rho_mesh, label='$\\rho$')
  ax1.plot(prob.xv_mesh, prob.pg_mesh, label='$P_g$')
  ax1.plot(prob.xv_mesh, prob.pc_mesh, label='$P_c$')
  ax1.plot(prob.xv_mesh, prob.fc_mesh, label='$F_c$')
  ax1.plot(prob.xv_mesh, prob.q_mesh, label='$Q$')

  ax2.semilogy(prob.xv_mesh, prob.alpha_mesh, label='$\\alpha$')
  ax2.semilogy(prob.xv_mesh, prob.beta_mesh, label='$\\beta$')
  ax2.semilogy(prob.xv_mesh, prob.eta_mesh, label='$\\eta$')
  ax2.semilogy(prob.xv_mesh, prob.delta_mesh, label='$\\delta$')

  ax1.legend(frameon=False)
  ax1.set_xlabel('$x$')
  ax1.margins(x=0)
  ax1.xaxis.set_minor_locator(AutoMinorLocator())
  ax1.yaxis.set_minor_locator(AutoMinorLocator())

  ax2.legend(frameon=False)
  ax2.set_xlabel('$x$')
  ax2.margins(x=0)
  ax2.xaxis.set_minor_locator(AutoMinorLocator())

  fig1.tight_layout()
  fig2.tight_layout()
  plt.show()

  # Save athena data
  with h5py.File('/Users/tsunhinnavintsung/Workspace/Codes/workspace/1dcr_v2_1/cr_thermal3/results/analytics/init_crprofile.hdf5', 'w') as fp:
    dset = fp.create_dataset('xv', data=prob.xv_mesh)
    dset = fp.create_dataset('xf', data=prob.xf_mesh)
    dset = fp.create_dataset('rho', data=prob.rho_mesh)
    dset = fp.create_dataset('pg', data=prob.pg_mesh)
    dset = fp.create_dataset('pc', data=prob.pc_mesh)
    dset = fp.create_dataset('fc', data=prob.fc_mesh)
    dset = fp.create_dataset('q', data=prob.q_mesh)
    dset = fp.create_dataset('L', data=prob.L_mesh)
    dset = fp.create_dataset('heat', data=prob.heat_mesh)
    dset = fp.create_dataset('bx', data=prob.bx_mesh)
    dset = fp.create_dataset('qv', data=prob.qv_mesh)
    dset = fp.create_dataset('qf', data=prob.qf_mesh)
    dset = fp.create_dataset('pc_xinner_bval', data=prob.pc_xinner_bval)
    dset = fp.create_dataset('pc_xouter_bval', data=prob.pc_xouter_bval)
    dset = fp.create_dataset('dd', data=prob.dd)
    fp.attrs.create('B', prob.BH)
    fp.attrs.create('kappa', prob.kappa)
    fp.attrs.create('g0', prob.g0)
    fp.attrs.create('T0', prob.T0)
    fp.attrs.create('alpha0', prob.alpha0)
    fp.attrs.create('beta0', prob.betac0)
    fp.attrs.create('nu', int(prob.nu))
    fp.attrs.create('Hc', prob.H)


  # ThermalStability Data manipulation
  num_var1 = 200

  alpha0 = 1.
  betaH = 100.
  etaH = 0.01
  chi0 = 0.20
  cool_index = -0.667

  rho0 = 1. 
  T0 = 1.
  g0 = 1.
  nu = 3
  taper = 0.3 # Equivalently a in input file

  wdwa = np.logspace(-5, 4, num_var1)

  therm_freq = np.zeros(num_var1)
  therm_growth = np.zeros(num_var1)

  problem = Profile(alpha0, betaH, etaH, chi0, rho0=rho0, T0=T0, g0=g0, nu=nu, taper=taper)

  x_target = prob.H
  rho = problem.Rho(x_target)
  drhodx = problem.Drhodx(x_target)
  cs = problem.cs 
  pg = problem.Pg(x_target)
  dpgdx = problem.Dpgdx(x_target)
  pc = problem.Pc(x_target) 
  dpcdx = problem.Dpcdx(x_target)
  B = problem.B(x_target)
  va = B/np.sqrt(rho)
  dvadx = va*(problem.Dbdx(x_target)/B - 0.5*drhodx/rho)
  kappa = problem.kappa
  cool = problem.L(x_target) 
  g = problem.G(x_target)

  for j, wda in enumerate(wdwa):
    k = wda*va/kappa
    wa = k*va 
    wc = rho**2*cool/pg

    thermstab = ThermalStability()
    roots = thermstab.growth(k, rho, drhodx, pg, dpgdx, pc, dpcdx, B, dvadx, kappa, cool, cool_index, g)
    max_growth = np.amax(np.imag(roots)) 
    max_growth_freq = np.real(roots[np.argmax(np.imag(roots))])
    max_growth_freq = max_growth_freq if max_growth > 0. else 0.
    max_growth = max_growth if max_growth > 0. else 0.
    therm_growth[j] = max_growth*wa/wc 
    therm_freq[j] = max_growth_freq

  fig1 = plt.figure()
  fig2 = plt.figure()
  ax1 = fig1.add_subplot(111)
  ax2 = fig2.add_subplot(111)

  # img1 = ax1.pcolormesh(wdwa_mesh, alphaH_mesh, therm_growth, norm=LogNorm(), cmap='magma')
  # img2 = ax2.pcolormesh(wdwa_mesh, alphaH_mesh, np.abs(therm_freq), norm=LogNorm(), cmap='magma')

  # ax1.set_xlabel('$\\omega_d/\\omega_A$')
  # ax1.set_ylabel('$\\alpha$')
  # ax1.set_xscale('log')
  # ax1.set_yscale('log')

  # ax2.set_xlabel('$\\omega_d/\\omega_A$')
  # ax2.set_ylabel('$\\alpha$')
  # ax2.set_xscale('log')
  # ax2.set_yscale('log')

  # fig1.colorbar(img1, label='$\\Gamma/\\omega_c$')
  # fig2.colorbar(img2, label='$\\nu/\\omega_A$')

  ax1.plot(wdwa, therm_growth)
  ax2.plot(wdwa, therm_freq)

  ax1.set_xlabel('$\\omega_d/\\omega_A$')
  ax1.set_ylabel('$\\Gamma/\\omega_c$')
  ax1.set_xscale('log')
  # ax1.set_yscale('log')
  ax1.margins(x=0)

  ax2.set_xlabel('$\\omega_d/\\omega_A$')
  ax2.set_ylabel('$\\nu/\\omega_A$')
  ax2.set_xscale('log')
  # ax2.set_yscale('log')
  ax2.margins(x=0)

  fig1.tight_layout()
  fig2.tight_layout()

  plt.show()



  # # TwoMomentStability Data manipulation
  # k = 2.*np.pi/prob.dx 
  # c = 1000.

  # cs = np.sqrt(gg*prob.pg_mesh/prob.rho_mesh)
  # cc = np.sqrt(gc*prob.pc_mesh/prob.rho_mesh)
  # va = prob.B/np.sqrt(prob.rho_mesh)
  # Lc = np.abs(prob.pc_mesh/prob.dpcdx_mesh)

  # wg = k*cs
  # nua = k*va/wg 
  # nuc = k*cc/wg 
  # nud = k**2*prob.kappa/wg
  # nums = (c**2/(gc*Lc*va))/wg
  # numd = (c**2/prob.kappa)/wg 
  # numtot = (c**2/(prob.kappa + gc*Lc*va))/wg 

  # roots = np.zeros((prob.meshgrid, 6), dtype=complex)
  # growth = np.zeros(prob.meshgrid)

  # for i, xv in enumerate(prob.xv_mesh):
  #   stab = TwoMomentStability(nua[i], nuc[i], nud[i], nums[i], numd[i], numtot[i], va[i], cc[i], c)
  #   stab.modes(k*Lc[i])
  #   roots[i, :] = stab.roots
  #   gwth = np.amax(np.imag(roots[i, :]))
  #   growth[i] = gwth if gwth > 0. else 0.

  # # Relative ordering of the characteristic frequencies
  # fig = plt.figure()
  # fig1 = plt.figure()
  # ax = fig.add_subplot(111)
  # ax1 = fig1.add_subplot(111)

  # ax.semilogy(prob.xv_mesh, nua, label='$\\nu_A$')
  # ax.semilogy(prob.xv_mesh, nuc, label='$\\nu_c$')
  # ax.semilogy(prob.xv_mesh, nud, label='$\\nu_d$')
  # ax.semilogy(prob.xv_mesh, nums, label='$\\nu_{ms}$')
  # ax.semilogy(prob.xv_mesh, numd, label='$\\nu_{md}$')
  # ax.semilogy(prob.xv_mesh, k*Lc, label='$k L_c$')
  # ax.semilogy(prob.xv_mesh, c/va, label='$c/v_A$')
  # ax.semilogy(prob.xv_mesh, c/cs, label='$c/c_s$')
  # ax.semilogy(prob.xv_mesh, c/cc, label='$c/c_c$')

  # ax1.plot(prob.xv_mesh, growth, label='$\\Gamma/k c_s$')

  # ax.legend(frameon=False)
  # ax.set_xlabel('$x$')
  # ax.margins(x=0)

  # ax1.legend(frameon=False)
  # ax1.set_xlabel('$x$')
  # ax1.set_ylabel('$\\Gamma/k c_s$')
  # ax1.margins(x=0)

  # fig.tight_layout()
  # fig1.tight_layout()

  # plt.show()

  # # TwoMomentStability threshold
  # nc = 1.
  # na = 1.
  # nd = np.logspace(-2, 2, 1000)
  # nms = 1.
  # nmd = 100.
  # nmtot = 1./(1./nms + 1./nmd)
  # cc = nc 
  # va = na 
  # c = 100.
  # kL = 1e3

  # freq = np.zeros((np.size(nd), 6))
  # growth = np.zeros((np.size(nd), 6))

  # for i, nnd in enumerate(nd):
  #   thres = TwoMomentStability(nc, na, nnd, nms, nmd, nmtot, cc, va, c)
  #   thres.modes(1e3)
  #   freq[i, :] = np.real(thres.roots)
  #   growth[i, :] = np.imag(thres.roots)

  # fig1 = plt.figure()
  # fig2 = plt.figure()
  # ax1 = fig1.add_subplot(111)
  # ax2 = fig2.add_subplot(111)

  # for i in range(6):
  #   ax1.scatter(nd, growth[:, i], color='k')
  #   ax2.scatter(nd, freq[:, i], color='k')

  # ax1.set_xlabel('$\\nu_d$')
  # ax1.set_ylabel('$\\Gamma$')
  # ax1.yaxis.set_minor_locator(AutoMinorLocator())
  # ax1.set_xscale('log')
  # ax1.margins(x=0)

  # ax2.set_xlabel('$\\nu_d$')
  # ax2.set_ylabel('$\\nu$')
  # ax2.yaxis.set_minor_locator(AutoMinorLocator())
  # ax2.set_xscale('log')
  # ax2.margins(x=0)

  # fig1.tight_layout()
  # fig2.tight_layout()
  # plt.show()















