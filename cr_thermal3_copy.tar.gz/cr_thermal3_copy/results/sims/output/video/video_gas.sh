#!/bin/bash
ffmpeg -r 10 -f image2 -s 389x470 -i ./gas_video%d.png -vcodec libx264 -crf 10 -pix_fmt yuv420p -vf scale=1500:1500 gas.mp4
