# Import installed packages
import sys
import itertools
import numpy as np 
import numpy.linalg as LA
from scipy import stats
import matplotlib.pyplot as plt 
import matplotlib.gridspec as gs
import matplotlib.legend as lg
from matplotlib import colors
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
from matplotlib.collections import PatchCollection
from matplotlib.patches import Rectangle
from mpl_toolkits.axes_grid1 import make_axes_locatable
import h5py
from mpi4py import MPI

# Import athena data reader
sys.path.append('/Users/tsunhinnavintsung/Workspace/Codes/Athena++')
import athena_read3 as ar 

# Matplotlib default param
plt.rcParams['font.size'] = 12
plt.rcParams['legend.fontsize'] = 12
plt.rcParams['legend.loc'] = 'best'
plt.rcParams['lines.linewidth'] = 1.5
plt.rcParams['lines.markersize'] = 2.
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['font.family'] = 'STIXGeneral'

def plotdefault():
  plt.rcParams.update(plt.rcParamsDefault)
  plt.rcParams['font.size'] = 12
  plt.rcParams['legend.fontsize'] = 12
  plt.rcParams['legend.loc'] = 'best'
  plt.rcParams['lines.linewidth'] = 1.5
  plt.rcParams['lines.markersize'] = 2.
  plt.rcParams['mathtext.fontset'] = 'stix'
  plt.rcParams['font.family'] = 'STIXGeneral'
  return

def latexify(columns=2, square=False, num_fig=0):
  """
  Set up matplotlib's RC params for LaTeX plotting.
  Call this before plotting a figure.
  Parameters
  ----------
  columns : {1, 2}
  """
  assert(columns in [1, 2])

  fig_width_pt = 240.0 if (columns == 1) else 504.0
  inches_per_pt = 1./72.27 # Convert pt to inch
  golden_mean = (np.sqrt(5.) - 1.)/2. 
  square_size = 1.
  fig_width = fig_width_pt*inches_per_pt # Width in inches
  fig_height = fig_width*golden_mean
  if square:
    fig_height = fig_width*square_size # Height in inches
  if num_fig != 0:
    fig_height = fig_width/num_fig
  fig_size = [fig_width, fig_height]

  font_size = 10 if columns == 1 else 12

  plt.rcParams['pdf.fonttype'] = 42
  plt.rcParams['ps.fonttype'] = 42
  plt.rcParams['font.size'] = font_size
  plt.rcParams['axes.labelsize'] = font_size
  plt.rcParams['axes.titlesize'] = font_size
  plt.rcParams['xtick.labelsize'] = font_size
  plt.rcParams['ytick.labelsize'] = font_size
  plt.rcParams['legend.fontsize'] = font_size
  plt.rcParams['figure.figsize'] = fig_size
  plt.rcParams['figure.titlesize'] = 12
  return 

# Global parameters
gc = 4./3.
gg = 5./3.
gc1 = gc/(gc - 1.)
gg1 = gg/(gg - 1.)
tiny_number = 1.e-10

class Plot2d:
  def __init__(self, inputfile, file_array, make_video=False, make_line_video=False, cloud_find=False):
    self.inputfile = inputfile
    self.file_array = file_array
    self.isothermal = True
    self.cr = False 
    self.b_field = False 
    self.open_file()

    # Check what physics is present
    if 'press'.encode('utf-8') in ar.athdf('./' + self.filename + '.out1.' + format(file_array[0], '05d') + '.athdf')['VariableNames']:
      self.isothermal = False
    if 'Ec'.encode('utf-8') in ar.athdf('./' + self.filename + '.out1.' + format(file_array[0], '05d') + '.athdf')['VariableNames']:
      self.cr = True
    if 'Bcc1'.encode('utf-8') in ar.athdf('./' + self.filename + '.out1.' + format(file_array[0], '05d') + '.athdf')['VariableNames']:
      self.b_field = True

    if make_video:
      pass
    elif make_line_video:
      pass
    elif cloud_find:
      pass
    else:
      self.read_data()
    self.runline = False 


  def is_number(self, n):
    try:
      float(n)   
    except ValueError:
      return False
    return True

  def open_file(self):
    with open(self.inputfile, 'r') as fp:
      line = fp.readline()
      self.nx1 = 0
      self.nx2 = 0
      self.user_output = False
      while line:
        phrase = line.strip().split(' ')
        for word in phrase:
          if word == 'problem_id':
            self.filename = line.split('=')[1].strip().split(' ')[0]
          elif word == 'nx1':
            grid = int(line.split('=')[1].strip().split(' ')[0])
            self.nx1 = grid if grid > self.nx1 else self.nx1 
          elif word == 'nx2':
            grid = int(line.split('=')[1].strip().split(' ')[0])
            self.nx2 = grid if grid > self.nx2 else self.nx2 
          elif word == 'dt':
            for element in phrase:
              if self.is_number(element):
                self.dt = float(element)
          elif word == 'x1min':
            for element in phrase:
              if self.is_number(element):
                self.x1min = float(element)
          elif word == 'x1max':
            for element in phrase:
              if self.is_number(element):
                self.x1max = float(element)
          elif word == 'x2min':
            for element in phrase:
              if self.is_number(element):
                self.x2min = float(element)
          elif word == 'x2max':
            for element in phrase:
              if self.is_number(element):
                self.x2max = float(element)
          elif word == 'x3min':
            for element in phrase:
              if self.is_number(element):
                self.x3min = float(element)
          elif word == 'x3max':
            for element in phrase:
              if self.is_number(element):
                self.x3max = float(element)
          elif word == 'gamma':
            for element in phrase:
              if self.is_number(element):
                gamma = float(element)
                if gamma != gg:
                  globals()[gg] = gamma
                  globals()[gg1] = gamma/(gamma - 1.)
                self.isothermal = False 
          elif word == 'iso_sound_speed':
            for element in phrase:
              if self.is_number(element):
                self.cs = float(element)
                self.isothermal = True
          elif word == 'uov':
            self.user_output = True
          elif word == 'vs_flag':
            for element in phrase:
              if self.is_number(element):
                self.cr_stream = True if int(element) == 1 else False
          elif word == 'gamma_c':
            for element in phrase:
              if self.is_number(element):
                gamma_c = float(element) 
                if gamma_c != gc:
                  globals()[gc] = gamma_c 
                  globals()[gc1] = gamma_c/(gamma_c - 1.)
          elif word == 'vmax':
            for element in phrase:
              if self.is_number(element):
                self.vmax = float(element) 
          else:
            continue  
        line = fp.readline()
    return 
      
  def read_data(self):
    filename = self.filename 

    # Choosing files for display
    file_array = self.file_array 
    self.time_array = np.zeros(np.size(file_array))

    # For no adaptive mesh refinement
    self.x1v = np.array(ar.athdf('./' + filename + '.out1.' + format(file_array[0], '05d') + '.athdf')['x1v'])
    self.x2v = np.array(ar.athdf('./' + filename + '.out1.' + format(file_array[0], '05d') + '.athdf')['x2v'])
    x1v = self.x1v
    x2v = self.x2v
    self.dx = x1v[1] - x1v[0]
    self.dy = x2v[1] - x2v[0]

    # Number of parameters of interest
    self.rho_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
    self.vx_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
    self.vy_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
    if not self.isothermal:
      self.pg_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
    if self.cr:
      self.ecr_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.fcx_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.fcy_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.vsx_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.vsy_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.sigmax_adv_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.sigmay_adv_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.sigmax_diff_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.sigmay_diff_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
    if self.b_field:
      self.bx_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))
      self.by_array = np.zeros((np.size(file_array), np.size(x2v), np.size(x1v)))

    # Preparing for uov
    if self.user_output:
      self.uovnum = ar.athdf('./' + filename + '.out2.' + format(file_array[0], '05d') + '.athdf')['NumVariables'][0]
      self.uovname = ar.athdf('./' + filename + '.out2.' + format(file_array[0], '05d') + '.athdf')['VariableNames']
      self.uovname = [self.uovname[i].decode('utf-8') for i in range(self.uovnum)] 
      self.uov_array = np.zeros((np.size(file_array), self.uovnum, np.size(x2v), np.size(x1v)))

    # Extracting data
    for i, file in enumerate(file_array):
      data = ar.athdf('./' + filename + '.out1.' + format(file, '05d') + '.athdf')
      self.time_array[i] = float('{0:f}'.format(data['Time']))
      self.rho_array[i, :, :] = data['rho'][0, :, :]
      self.vx_array[i, :, :] = data['vel1'][0, :, :]
      self.vy_array[i, :, :] = data['vel2'][0, :, :]
      if not self.isothermal:
        self.pg_array[i, :, :] = data['press'][0, :, :]
      if self.cr:
        self.ecr_array[i, :, :] = data['Ec'][0, :, :] 
        self.fcx_array[i, :, :] = data['Fc1'][0, :, :]*self.vmax
        self.fcy_array[i, :, :] = data['Fc2'][0, :, :]*self.vmax
        self.vsx_array[i, :, :] = data['Vc1'][0, :, :]
        self.vsy_array[i, :, :] = data['Vc2'][0, :, :]
        self.sigmax_adv_array[i, :, :] = data['Sigma_adv1'][0, :, :]/self.vmax
        self.sigmay_adv_array[i, :, :] = data['Sigma_adv2'][0, :, :]/self.vmax
        self.sigmax_diff_array[i, :, :] = data['Sigma_diff1'][0, :, :]/self.vmax
        self.sigmay_diff_array[i, :, :] = data['Sigma_diff2'][0, :, :]/self.vmax
      if self.b_field:
        self.bx_array[i, :, :] = data['Bcc1'][0, :, :]
        self.by_array[i, :, :] = data['Bcc2'][0, :, :]

      if self.user_output:
        uov_data = ar.athdf('./' + filename + '.out2.' + format(file, '05d') \
          + '.athdf')
        for j, uov_name in enumerate(self.uovname):
          self.uov_array[i, j, :, :] = uov_data[uov_name][0, :, :]
      
    # For constant kappa and magnetic field
    if self.cr:
      self.kappax = (gc - 1.)/self.sigmax_diff_array[0, 0, 0] 
      self.kappay = (gc - 1.)/self.sigmay_diff_array[0, 0, 0] 
    return 

  # file: which data file should be output
  def plot(self, file, log_den=False, log_therm=False, discrepant=None, aspects='equal'):
    file_index = np.where(self.file_array == file)[0][0]
    if discrepant != None:
      file_index = np.where(self.file_array == discrepant[0])[0][0]
      file_index_discrepant = np.where(self.file_array == discrepant[1])[0][0]
    time = self.time_array[file_index]
    if discrepant != None:
      time_discrepant = self.time_array[file_index_discrepant]
    x1v = self.x1v
    x2v = self.x2v
    skip1 = int(np.floor(self.nx1/20))
    skip2 = int(np.floor(self.nx2/20))
    self.skip1 = skip1 
    self.skip2 = skip2

    fig1 = plt.figure()
    fig2 = plt.figure()
    ax1 = fig1.add_subplot(111)
    ax2 = fig2.add_subplot(111)
    fig = [fig1, fig2]
    ax = [ax1, ax2]
    if discrepant == None:
      lab = ['$\\mathrm{log}(\\rho)$', '$v$'] if log_den else ['$\\rho$', '$v$']
    else:
      lab = ['$\\delta\\rho$', '$\\delta v$']
    if not self.isothermal:
      fig3 = plt.figure()
      fig6 = plt.figure()
      ax3 = fig3.add_subplot(111)
      ax6 = fig6.add_subplot(111)
      fig.append(fig3)
      fig.append(fig6)
      ax.append(ax3)
      ax.append(ax6)
      if discrepant == None:
        lab.append('$\\mathrm{log}(P_g)$') if log_therm else lab.append('$P_g$') 
        lab.append('$\\mathrm{log}(T)$') if log_therm else lab.append('$T$') 
      else:
        lab.append('$\\delta P_g$') 
        lab.append('$\\delta T$') 
    if self.cr:
      fig4 = plt.figure()
      ax4 = fig4.add_subplot(111)
      fig.append(fig4)
      ax.append(ax4)
      if discrepant == None:
        lab.append('$P_c$')
      else:
        lab.append('$\\delta P_c$')
    if self.b_field:
      fig5 = plt.figure()
      ax5 = fig5.add_subplot(111)
      fig.append(fig5)
      ax.append(ax5)
      if discrepant == None:
        lab.append('$B$')
      else:
        lab.append('$\\delta B$')

    if discrepant == None:
      if log_den:
        img1 = ax1.imshow(np.log10(self.rho_array[file_index, :, :]), cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      else: 
        img1 = ax1.imshow(self.rho_array[file_index, :, :], cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      img2 = ax2.imshow(np.sqrt(self.vx_array[file_index, :, :]**2 + self.vy_array[file_index, :, :]**2), \
        cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      img = [img1, img2]
      if not self.isothermal: 
        if log_therm:
          img3 = ax3.imshow(np.log10(self.pg_array[file_index, :, :]), cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
          img6 = ax6.imshow(np.log10(self.pg_array[file_index, :, :]/self.rho_array[file_index, :, :]), cmap='bwr', aspect='auto', origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        else:
          img3 = ax3.imshow(self.pg_array[file_index, :, :], cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
          img6 = ax6.imshow(self.pg_array[file_index, :, :]/self.rho_array[file_index, :, :], cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img3)
        img.append(img6)
      if self.cr:
        img4 = ax4.imshow(self.ecr_array[file_index, :, :]/3., cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img4)
      if self.b_field:
        img5 = ax5.imshow(np.sqrt(self.bx_array[file_index, :, :]**2 + self.by_array[file_index, :, :]**2), \
          cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img5)

      qui2 = ax2.quiver(x1v[::skip1], x2v[::skip2], self.vx_array[file_index, ::skip2, ::skip1], self.vy_array[file_index, ::skip2, ::skip1])
      if self.b_field:
        qui5 = ax5.quiver(x1v[::skip1], x2v[::skip2], self.bx_array[file_index, ::skip2, ::skip1], self.by_array[file_index, ::skip2, ::skip1])
    # Discrepant
    else:
      img1 = ax1.imshow(self.rho_array[file_index_discrepant, :, :] - self.rho_array[file_index, :, :], cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      img2 = ax2.imshow(np.sqrt(self.vx_array[file_index_discrepant, :, :]**2 + self.vy_array[file_index_discrepant, :, :]**2) \
        - np.sqrt(self.vx_array[file_index, :, :]**2 + self.vy_array[file_index, :, :]**2), \
        cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      img = [img1, img2]
      if not self.isothermal: 
        img3 = ax3.imshow(self.pg_array[file_index_discrepant, :, :] - self.pg_array[file_index, :, :], cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img6 = ax6.imshow(self.pg_array[file_index_discrepant, :, :]/self.rho_array[file_index_discrepant, :, :] - \
          self.pg_array[file_index, :, :]/self.rho_array[file_index, :, :], cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img3)
        img.append(img6)
      if self.cr:
        img4 = ax4.imshow(self.ecr_array[file_index_discrepant, :, :]/3. - self.ecr_array[file_index, :, :]/3., \
          cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img4)
      if self.b_field:
        img5 = ax5.imshow(np.sqrt(self.bx_array[file_index_discrepant, :, :]**2 + self.by_array[file_index_discrepant, :, :]**2) - \
          np.sqrt(self.bx_array[file_index, :, :]**2 + self.by_array[file_index, :, :]**2), \
          cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img5)

    for i, figu in enumerate(fig):
      divider = make_axes_locatable(ax[i])
      cax = divider.append_axes('right', size="5%", pad=0.0)
      figu.colorbar(img[i], ax=ax[i], label=lab[i], cax=cax)

    props = dict(boxstyle='round', facecolor='wheat')

    for i, axes in enumerate(ax):
      axes.text(0.8, 0.95, 't={:.2f}'.format(time), transform=axes.transAxes, bbox=props)
      axes.set_xlabel('$x$')
      axes.set_ylabel('$y$')
      axes.xaxis.set_minor_locator(AutoMinorLocator())
      axes.yaxis.set_minor_locator(AutoMinorLocator())

    for i, figu in enumerate(fig):
      figu.tight_layout()
    return fig

  # make video
  def make_video(self, savepath, log_den=False, log_therm=False, log_pc=False, log_beta=False,\
    x_start=None, x_end=None, y_start=None, y_end=None, aspects='equal'):
    file_array = self.file_array
    filename = self.filename

    for i, file in enumerate(file_array):
      # Extract data
      print(file_array[0] + i)
      data = ar.athdf('./' + filename + '.out1.' + format(file, '05d') + '.athdf')
      time = float('{0:f}'.format(data['Time']))
      x1v = data['x1v']
      x2v = data['x2v']
      xarg_start = np.argmin(np.abs(x1v - x_start)) if x_start != None else 0 
      xarg_end = np.argmin(np.abs(x1v - x_end)) if x_end != None else np.size(x1v) 
      yarg_start = np.argmin(np.abs(x2v - y_start)) if y_start != None else 0 
      yarg_end = np.argmin(np.abs(x2v - y_end)) if y_end != None else np.size(x2v)
      x1v = x1v[xarg_start:xarg_end]
      x2v = x2v[yarg_start:yarg_end]
      rho = data['rho'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      vx = data['vel1'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      vy = data['vel2'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      v = np.sqrt(vx**2 + vy**2)
      if not self.isothermal:
        pg = data['press'][0, yarg_start:yarg_end, xarg_start:xarg_end]
        T = pg/rho 
      if self.cr:
        pc = data['Ec'][0, yarg_start:yarg_end, xarg_start:xarg_end]*(gc - 1.)
        fcx = data['Fc1'][0, yarg_start:yarg_end, xarg_start:xarg_end]*self.vmax
        fcy = data['Fc2'][0, yarg_start:yarg_end, xarg_start:xarg_end]*self.vmax 
        fc = np.sqrt(fcx**2 + fcy**2)
      if self.b_field:
        bx = data['Bcc1'][0, yarg_start:yarg_end, xarg_start:xarg_end]
        by = data['Bcc2'][0, yarg_start:yarg_end, xarg_start:xarg_end]
        b = np.sqrt(bx**2 + by**2)
        if not self.isothermal:
          beta = b
        else:
          beta = 2.*rho*self.cs**2/b**2 

      fig1 = plt.figure()
      fig2 = plt.figure() 
      fig = [fig1, fig2]
      ax1 = fig1.add_subplot()
      ax2 = fig2.add_subplot()
      ax = [ax1, ax2]
      lab = ['$\\mathrm{log}(\\rho)$', '$v$'] if log_den else ['$\\rho$', '$v$']
      save = ['rho', 'v']
      if not self.isothermal:
        fig3 = plt.figure()
        fig4 = plt.figure()
        fig.append(fig3)
        fig.append(fig4)
        ax3 = fig3.add_subplot(111)
        ax4 = fig4.add_subplot(111)
        ax.append(ax3)
        ax.append(ax4)
        lab.append('$\\mathrm{log}(P_g)$') if log_therm else lab.append('$P_g$') 
        lab.append('$\\mathrm{log}(T)$') if log_therm else lab.append('$T$') 
        save.append('pg')
        save.append('T')
      if self.cr:
        fig5 = plt.figure()
        fig6 = plt.figure() 
        fig.append(fig5)
        fig.append(fig6)
        ax5 = fig5.add_subplot(111)
        ax6 = fig6.add_subplot(111) 
        ax.append(ax5)
        ax.append(ax6)
        lab.append('$\\mathrm{log}(P_c)$') if log_pc else lab.append('$P_c$')
        lab.append('$F_c$')
        save.append('pc')
        save.append('fc')
      if self.b_field:
        fig7 = plt.figure()
        fig.append(fig7)
        ax7 = fig7.add_subplot(111)
        ax.append(ax7)
        lab.append('$\\mathrm{log}(\\beta)$') if log_beta else lab.append('$\\beta$')
        save.append('beta')

      if log_den:
        img1 = ax1.imshow(np.log10(rho), cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      else: 
        img1 = ax1.imshow(rho, cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      img2 = ax2.imshow(v, cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
      img = [img1, img2]
      if not self.isothermal:
        if log_therm:
          img3 = ax3.imshow(np.log10(pg), cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
          img4 = ax4.imshow(np.log10(T), cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        else:
          img3 = ax3.imshow(pg, cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
          img4 = ax4.imshow(T, cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img3)
        img.append(img4)
      if self.cr:
        if log_pc:
          img5 = ax5.imshow(np.log10(pc), cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        else:
          img5 = ax5.imshow(pc, cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img6 = ax6.imshow(fc, cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img5)
        img.append(img6)
      if self.b_field:
        if log_beta:
          img7 = ax7.imshow(np.log10(beta), cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        else:
          img7 = ax7.imshow(beta, cmap='bwr', aspect=aspects, origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        img.append(img7)

      for j, figu in enumerate(fig):
        divider = make_axes_locatable(ax[j])
        cax = divider.append_axes('right', size="5%", pad=0.0)
        figu.colorbar(img[j], ax=ax[j], label=lab[j], cax=cax)

      props = dict(boxstyle='round', facecolor='wheat')

      for j, axes in enumerate(ax):
        axes.text(0.8, 0.95, 't={:.2f}'.format(time), transform=axes.transAxes, bbox=props)
        axes.set_xlabel('$x$')
        axes.set_ylabel('$y$')
        axes.xaxis.set_minor_locator(AutoMinorLocator())
        axes.yaxis.set_minor_locator(AutoMinorLocator())

      for j, figu in enumerate(fig):
        figu.tight_layout()
        addpath = save[j] + str(file_array[0] + i)
        figu.savefig(savepath + addpath, dpi=300)

      # Close and redraw to prevent memory overload
      plt.close('all')

    return

  # make line video
  def make_line_video(self, savepath, x_or_y='x', quartile=0.5, \
    log_den=False, log_therm=False, log_pc=False, log_beta=False,):
    file_array = self.file_array
    filename = self.filename

    self.x_or_y = x_or_y
    if x_or_y == 'x':
      ndex = int(np.floor(self.nx2*quartile))
    elif x_or_y == 'y':
      ndex = int(np.floor(self.nx1*quartile))
    else:
      raise(ValueError('Must input x or y!'))

    for i, file in enumerate(file_array):
      # Extract data
      print(file_array[0] + i)
      data = ar.athdf('./' + filename + '.out1.' + format(file, '05d') + '.athdf')
      time = float('{0:f}'.format(data['Time']))
      x1v = data['x1v']
      x2v = data['x2v']
      if x_or_y == 'x':
        rho = data['rho'][0, ndex, :]
        vx = data['vel1'][0, ndex, :]
        vy = data['vel2'][0, ndex, :]
        v = np.sqrt(vx**2 + vy**2)
        if not self.isothermal:
          pg = data['press'][0, ndex, :]
          T = pg/rho 
        if self.cr:
          pc = data['Ec'][0, ndex, :]*(gc - 1.)
          fcx = data['Fc1'][0, ndex, :]*self.vmax
          fcy = data['Fc2'][0, ndex, :]*self.vmax 
          fc = np.sqrt(fcx**2 + fcy**2)
        if self.b_field:
          bx = data['Bcc1'][0, ndex, :]
          by = data['Bcc2'][0, ndex, :]
          b = np.sqrt(bx**2 + by**2)
          if not self.isothermal:
            beta = b
          else:
            beta = 2.*pg/b**2 
      elif x_or_y == 'y':
        rho = data['rho'][0, :, ndex]
        vx = data['vel1'][0, :, ndex]
        vy = data['vel2'][0, :, ndex]
        v = np.sqrt(vx**2 + vy**2)
        if not self.isothermal:
          pg = data['press'][0, :, ndex]
          T = pg/rho 
        if self.cr:
          pc = data['Ec'][0, :, ndex]*(gc - 1.)
          fcx = data['Fc1'][0, :, ndex]*self.vmax
          fcy = data['Fc2'][0, :, ndex]*self.vmax 
          fc = np.sqrt(fcx**2 + fcy**2)
        if self.b_field:
          bx = data['Bcc1'][0, :, ndex]
          by = data['Bcc2'][0, :, ndex]
          b = np.sqrt(bx**2 + by**2)
          if not self.isothermal:
            beta = b
          else:
            beta = 2.*pg/b**2 

      fig = plt.figure(figsize=(12, 6))
      grids = gs.GridSpec(2, 4, figure=fig)
      ax1 = fig.add_subplot(grids[0, 0])
      ax2 = fig.add_subplot(grids[0, 1])
      ax = [ax1, ax2]
      lab = ['$\\mathrm{log}(\\rho)$', '$v$'] if log_den else ['$\\rho$', '$v$']
      if not self.isothermal:
        ax3 = fig.add_subplot(grids[0, 2])
        ax4 = fig.add_subplot(grids[0, 3])
        ax.append(ax3)
        ax.append(ax4)
        lab.append('$\\mathrm{log}(P_g)$') if log_therm else lab.append('$P_g$') 
        lab.append('$\\mathrm{log}(T)$') if log_therm else lab.append('$T$') 
      if self.cr:
        ax5 = fig.add_subplot(grids[1, 0])
        ax6 = fig.add_subplot(grids[1, 1]) 
        ax.append(ax5)
        ax.append(ax6)
        lab.append('$\\mathrm{log}(P_c)$') if log_pc else lab.append('$P_c$')
        lab.append('$F_c$')
      if self.b_field:
        ax7 = fig.add_subplot(grids[1, 2])
        ax.append(ax7)
        lab.append('$\\mathrm{log}(\\beta)$') if log_beta else lab.append('$\\beta$')

      if log_den:
        ax1.semilogy(x1v, rho, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax1.semilogy(x2v, rho, 'o-', label='t={:.2f}'.format(time))
      else: 
        ax1.plot(x1v, rho, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax1.semilogy(x2v, rho, 'o-', label='t={:.2f}'.format(time))
      ax2.plot(x1v, v, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax2.semilogy(x2v, v, 'o-', label='t={:.2f}'.format(time))
      if not self.isothermal:
        if log_therm:
          ax3.semilogy(x1v, pg, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax3.semilogy(x2v, pg, 'o-', label='t={:.2f}'.format(time))
          ax4.semilogy(x1v, T, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax4.semilogy(x2v, T, 'o-', label='t={:.2f}'.format(time))
        else:
          ax3.plot(x1v, pg, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax3.semilogy(x2v, pg, 'o-', label='t={:.2f}'.format(time))
          ax4.plot(x1v, T, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax4.semilogy(x2v, T, 'o-', label='t={:.2f}'.format(time))
      if self.cr:
        if log_pc:
          ax5.semilogy(x1v, pc, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax5.semilogy(x2v, pc, 'o-', label='t={:.2f}'.format(time))
        else:
          ax5.plot(x1v, pc, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax5.semilogy(x2v, pc, 'o-', label='t={:.2f}'.format(time))
        ax6.semilogy(x1v, fc, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax6.semilogy(x2v, fc, 'o-', label='t={:.2f}'.format(time))
      if self.b_field:
        if log_beta:
          ax7.semilogy(x1v, beta, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax7.semilogy(x2v, beta, 'o-', label='t={:.2f}'.format(time))
        else:
          ax7.plot(x1v, beta, 'o-', label='t={:.2f}'.format(time)) if x_or_y == 'x' else ax7.semilogy(x2v, beta, 'o-', label='t={:.2f}'.format(time))


      for j, axes in enumerate(ax):
        axes.legend(frameon=False)
        axes.set_xlabel('$x$') if x_or_y == 'x' else axes.set_xlabel('$y$')
        axes.set_ylabel(lab[j])
        axes.xaxis.set_minor_locator(AutoMinorLocator())

      fig.tight_layout()
      addpath = 'line' + str(file_array[0] + i)
      fig.savefig(savepath + addpath, dpi=300)

      # Close and redraw to prevent memory overload
      plt.close('all')

    return

  # x_or_y: Line taken along x or y
  # quartile: 0.5 means at the middle
  def line(self, file, x_or_y='x', quartile=0.5, log_indep=False, log_dep=False):
    self.runline = True
    self.x_or_y = x_or_y
    file_index = np.where(self.file_array == file)[0][0]
    time = self.time_array[file_index]
    x1v = self.x1v 
    x2v = self.x2v
    if x_or_y == 'x':
      ndex = int(np.floor(self.nx2*quartile))
    elif x_or_y == 'y':
      ndex = int(np.floor(self.nx1*quartile))
    else:
      raise(ValueError('Must input x or y!'))

    if x_or_y == 'x':
      self.rho_line = self.rho_array[file_index, ndex, :]
      self.vx_line = self.vx_array[file_index, ndex, :]
      self.vy_line = self.vy_array[file_index, ndex, :]
      if not self.isothermal:
        self.pg_line = self.pg_array[file_index, ndex, :]
      if self.cr:
        self.ecr_line = self.ecr_array[file_index, ndex, :]
        self.fcx_line = self.fcx_array[file_index, ndex, :]
        self.fcy_line = self.fcy_array[file_index, ndex, :]
      if self.b_field:
        self.bx_line = self.bx_array[file_index, ndex, :]
        self.by_line = self.by_array[file_index, ndex, :]
    elif x_or_y == 'y':
      self.rho_line = self.rho_array[file_index, :, ndex]
      self.vx_line = self.vx_array[file_index, :, ndex]
      self.vy_line = self.vy_array[file_index, :, ndex]
      if not self.isothermal:
        self.pg_line = self.pg_array[file_index, :, ndex]
      if self.cr:
        self.ecr_line = self.ecr_array[file_index, :, ndex]
      if self.b_field:
        self.bx_line = self.bx_array[file_index, :, ndex]
        self.by_line = self.by_array[file_index, :, ndex]
    else:
      pass

    fig = plt.figure(figsize=(12, 8))
    grids = gs.GridSpec(3, 3, figure=fig)
    ax1 = fig.add_subplot(grids[0, 0])
    ax2 = fig.add_subplot(grids[0, 1])
    ax3 = fig.add_subplot(grids[0, 2])
    ax = [ax1, ax2, ax3]
    ax_vector = [False, True, True]
    lab = ['$\\rho$', '$v_x$', '$v_y$']
    if not self.isothermal:
      ax4 = fig.add_subplot(grids[1, 0])
      ax5 = fig.add_subplot(grids[1, 1])
      ax.append(ax4)
      ax.append(ax5)
      ax_vector.append(False)
      ax_vector.append(False)
      lab.append('$P_g$')
      lab.append('$T$')
    if self.cr:
      ax6 = fig.add_subplot(grids[1, 2])
      ax7 = fig.add_subplot(grids[2, 0])
      ax.append(ax6)
      ax.append(ax7)
      ax_vector.append(False)
      ax_vector.append(True)
      lab.append('$P_c$')
      lab.append('$F_c$')
    if self.b_field:
      ax8 = fig.add_subplot(grids[2, 1])
      ax9 = fig.add_subplot(grids[2, 2])
      ax.append(ax8)
      ax.append(ax9)
      ax_vector.append(True)
      ax_vector.append(True)
      lab.append('$B_x$')
      lab.append('$B_y$')

    if x_or_y == 'x':
      ax1.plot(x1v, self.rho_array[file_index, ndex, :], 'o-',  label='t={:.2f}'.format(time))
      ax2.plot(x1v, self.vx_array[file_index, ndex, :], 'o-', label='t={:.2f}'.format(time))
      ax3.plot(x1v, self.vy_array[file_index, ndex, :], 'o-', label='t={:.2f}'.format(time))
      if not self.isothermal:
        ax4.plot(x1v, self.pg_array[file_index, ndex, :], 'o-', label='t={:.2f}'.format(time))
        ax5.plot(x1v, self.pg_array[file_index, ndex, :]/self.rho_array[file_index, ndex, :], 'o-',  label='t={:.2f}'.format(time))
      if self.cr:
        ax6.plot(x1v, self.ecr_array[file_index, ndex, :]/3., 'o-', label='t={:.2f}'.format(time))
        ax7.plot(x1v, self.fcx_array[file_index, ndex, :], 'o-', label='t={:.2f}'.format(time))
      if self.b_field:
        ax8.plot(x1v, self.bx_array[file_index, ndex, :], 'o-', label='t={:.2f}'.format(time))
        ax9.plot(x1v, self.by_array[file_index, ndex, :], 'o-', label='t={:.2f}'.format(time))
    elif x_or_y == 'y':
      ax1.plot(x2v, self.rho_array[file_index, :, ndex], 'o-',  label='t={:.2f}'.format(time))
      ax2.plot(x2v, self.vx_array[file_index, :, ndex], 'o-', label='t={:.2f}'.format(time))
      ax3.plot(x2v, self.vy_array[file_index, :, ndex], 'o-', label='t={:.2f}'.format(time))
      if not self.isothermal:
        ax4.plot(x2v, self.pg_array[file_index, :, ndex], 'o-', label='t={:.2f}'.format(time))
        ax5.plot(x2v, self.pg_array[file_index, :, ndex]/self.rho_array[file_index, :, ndex], 'o-',  label='t={:.2f}'.format(time))
      if self.cr:
        ax6.plot(x2v, self.ecr_array[file_index, :, ndex]/3., 'o-', label='t={:.2f}'.format(time))
        ax7.plot(x2v, self.fcx_array[file_index, :, ndex], 'o-', label='t={:.2f}'.format(time))
      if self.b_field:
        ax8.plot(x2v, self.bx_array[file_index, :, ndex], 'o-', label='t={:.2f}'.format(time))
        ax9.plot(x2v, self.by_array[file_index, :, ndex], 'o-', label='t={:.2f}'.format(time))
    else:
      pass

    for i, axes in enumerate(ax):
      axes.legend(frameon=False)
      if x_or_y == 'x':
        axes.set_xlabel('$x$')
      elif x_or_y == 'y':
        axes.set_xlabel('$y$')
      else:
        pass
      axes.set_ylabel(lab[i])
      if log_indep:
        axes.set_xscale('log')
      else:
        axes.xaxis.set_minor_locator(AutoMinorLocator())
      if log_dep and (not ax_vector[i]):
        axes.set_yscale('log')
      else:
        axes.yaxis.set_minor_locator(AutoMinorLocator())

    fig.tight_layout()
    return fig

  # Project 2d plots to 1d
  # x_or_y means project onto x or y axis
  def project1d(self, x_or_y='x', log_indep=False, log_dep=False):
    file_array = self.file_array
    filename = self.filename
    num_grid = self.nx1 if x_or_y == 'x' else self.nx2
    sum_axis = 0 if x_or_y == 'x' else 1

    # Prepare memory for projection data
    rho_project1d = np.zeros(num_grid)
    vx_project1d = np.zeros(num_grid)
    vy_project1d = np.zeros(num_grid)
    if not self.isothermal:
      pg_project1d = np.zeros(num_grid)
      T_project1d = np.zeros(num_grid)
    if self.cr:
      pc_project1d = np.zeros(num_grid)
      fcx_project1d = np.zeros(num_grid)
      fcy_project1d = np.zeros(num_grid)

    if (self.isothermal and (not self.cr)):
      fig = plt.figure(figsize=(9, 3))
      grids = gs.GridSpec(1, 3, figure=fig)
      ax1 = fig.add_subplot(grids[0, 0])
      ax2 = fig.add_subplot(grids[0, 1])
      ax3 = fig.add_subplot(grids[0, 2])
      ax = [ax1, ax2, ax3]
      ax_vec = [ax2, ax3]
      lab = ['$\\rho$', '$v_x$', '$v_y$']
    elif ((not self.isothermal) and (not self.cr)):
      fig = plt.figure(figsize=(12, 3))
      grids = gs.GridSpec(1, 4, figure=fig)
      ax1 = fig.add_subplot(grids[0, 0])
      ax2 = fig.add_subplot(grids[0, 1])
      ax3 = fig.add_subplot(grids[0, 2])
      ax4 = fig.add_subplot(grids[0, 3])
      ax = [ax1, ax2, ax3, ax4]
      ax_vec = [ax2, ax3]
      lab = ['$\\rho$', '$v_x$', '$v_y$', '$P_g$']
    elif (self.isothermal and self.cr):
      fig = plt.figure(figsize=(9, 6))
      grids = gs.GridSpec(2, 3, figure=fig)
      ax1 = fig.add_subplot(grids[0, 0])
      ax2 = fig.add_subplot(grids[0, 1])
      ax3 = fig.add_subplot(grids[0, 2])
      ax4 = fig.add_subplot(grids[1, 0])
      ax5 = fig.add_subplot(grids[1, 1])
      ax6 = fig.add_subplot(grids[1, 2])
      ax = [ax1, ax2, ax3, ax4, ax5, ax6]
      ax_vec = [ax2, ax3, ax5, ax6]
      lab = ['$\\rho$', '$v_x$', '$v_y$', '$P_c$', '$F_{cx}$', '$F_{cy}$']
    elif ((not self.isothermal) and self.cr):
      fig = plt.figure(figsize=(9, 6))
      grids = gs.GridSpec(2, 3, figure=fig)
      ax1 = fig.add_subplot(grids[0, 0])
      ax2 = fig.add_subplot(grids[0, 1])
      ax3 = fig.add_subplot(grids[0, 2])
      ax4 = fig.add_subplot(grids[1, 0])
      ax5 = fig.add_subplot(grids[1, 1])
      ax6 = fig.add_subplot(grids[1, 2])
      ax = [ax1, ax2, ax3, ax4, ax5, ax6]
      ax_vec = [ax2, ax3, ax6]
      lab = ['$\\rho$', '$v_x$', '$v_y$', '$P_g$', '$P_c$', '$F_{cx}$']

    for i, file in enumerate(file_array):
      # Extract data
      time = self.time_array[i]
      coord = self.x1v if x_or_y == 'x' else self.x2v
      rho_project1d[:] = np.sum(self.rho_array[i, :, :], axis=sum_axis)/num_grid 
      vx_project1d[:] = np.sum(self.vx_array[i, :, :], axis=sum_axis)/num_grid
      vy_project1d[:] = np.sum(self.vy_array[i, :, :], axis=sum_axis)/num_grid
      if not self.isothermal:
        pg_project1d[:] = np.sum(self.pg_array[i, :, :], axis=sum_axis)/num_grid
        T_project1d[:] = pg_project1d/rho_project1d 
      if self.cr:
        pc_project1d[:] = np.sum(self.ecr_array[i, :, :]*(gc - 1.), axis=sum_axis)/num_grid
        fcx_project1d[:] = np.sum(self.fcx_array[i, :, :], axis=sum_axis)/num_grid
        fcy_project1d[:] = np.sum(self.fcx_array[i, :, :], axis=sum_axis)/num_grid

      # Plot
      if (file == 0):
        if (self.isothermal and (not self.cr)):
          ax1.plot(coord, rho_project1d, 'k--', label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, 'k--', label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, 'k--', label='t={:.2f}'.format(time))
        elif ((not self.isothermal) and (not self.cr)):
          ax1.plot(coord, rho_project1d, 'k--', label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, 'k--', label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, 'k--', label='t={:.2f}'.format(time))
          ax4.plot(coord, pg_project1d, 'k--', label='t={:.2f}'.format(time))
        elif (self.isothermal and self.cr):
          ax1.plot(coord, rho_project1d, 'k--', label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, 'k--', label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, 'k--', label='t={:.2f}'.format(time))
          ax4.plot(coord, pc_project1d, 'k--', label='t={:.2f}'.format(time))
          ax5.plot(coord, fcx_project1d, 'k--', label='t={:.2f}'.format(time))
          ax6.plot(coord, fcy_project1d, 'k--', label='t={:.2f}'.format(time))
        elif ((not self.isothermal) and self.cr):
          ax1.plot(coord, rho_project1d, 'k--', label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, 'k--', label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, 'k--', label='t={:.2f}'.format(time))
          ax4.plot(coord, pg_project1d, 'k--', label='t={:.2f}'.format(time))
          ax5.plot(coord, pc_project1d, 'k--', label='t={:.2f}'.format(time))
          ax6.plot(coord, fcx_project1d, 'k--', label='t={:.2f}'.format(time))
      else:
        if (self.isothermal and (not self.cr)):
          ax1.plot(coord, rho_project1d, label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, label='t={:.2f}'.format(time))
        elif ((not self.isothermal) and (not self.cr)):
          ax1.plot(coord, rho_project1d, label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, label='t={:.2f}'.format(time))
          ax4.plot(coord, pg_project1d, label='t={:.2f}'.format(time))
        elif (self.isothermal and self.cr):
          ax1.plot(coord, rho_project1d, label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, label='t={:.2f}'.format(time))
          ax4.plot(coord, pc_project1d, label='t={:.2f}'.format(time))
          ax5.plot(coord, fcx_project1d, label='t={:.2f}'.format(time))
          ax6.plot(coord, fcy_project1d, label='t={:.2f}'.format(time))
        elif ((not self.isothermal) and self.cr):
          ax1.plot(coord, rho_project1d, label='t={:.2f}'.format(time))
          ax2.plot(coord, vx_project1d, label='t={:.2f}'.format(time))
          ax3.plot(coord, vy_project1d, label='t={:.2f}'.format(time))
          ax4.plot(coord, pg_project1d, label='t={:.2f}'.format(time))
          ax5.plot(coord, pc_project1d, label='t={:.2f}'.format(time))
          ax6.plot(coord, fcx_project1d, label='t={:.2f}'.format(time))

    for i, axes in enumerate(ax):
      if x_or_y == 'x':
        axes.set_xlabel('$x$')
      else: 
        axes.set_xlabel('$y$') 
      axes.set_ylabel(lab[i])
      if log_indep:
        axes.set_xscale('log') 
      else:
        axes.xaxis.set_minor_locator(AutoMinorLocator())
      if log_dep and (axes not in ax_vec):
        axes.set_yscale('log')
      else:
        axes.yaxis.set_minor_locator(AutoMinorLocator())
      axes.margins(x=0)
      axes.legend(frameon=False)

    fig.tight_layout()
    return fig

  # Pan in 1d
  def pan1d(self):
    if self.runline == False:
      raise(ValueError('Run line() function first.'))

    # Prompt the user to enter values
    time = float(input('Enter time: '))
    begin = float(input('Enter begining of shock: '))
    end = float(input('Enter ending of shock: '))
    start = float(input('Enter start of check: '))
    check = float(input('Enter end of check: '))

    file = np.argmin(np.abs(self.time_array - time))
    if self.x_or_y == 'x':
      ibeg = np.argmin(np.abs(self.x1v - begin))
      iend = np.argmin(np.abs(self.x1v - end))
      x_pan = self.x1v[ibeg:iend]
      istr = np.argmin(np.abs(x_pan - start))
      ichk = np.argmin(np.abs(x_pan - check))
    elif self.x_or_y == 'y':
      ibeg = np.argmin(np.abs(self.x2v - begin))
      iend = np.argmin(np.abs(self.x2v - end))
      x_pan = self.x2v[ibeg:iend]
      istr = np.argmin(np.abs(x_pan - start))
      ichk = np.argmin(np.abs(x_pan - check))

    # Extract variables
    rho_pan = self.rho_line[ibeg:iend]
    vx_pan = self.vx_line[ibeg:iend]
    vy_pan = self.vy_line[ibeg:iend]
    if not self.isothermal:
      pg_pan = self.pg_line[ibeg:iend]
    if self.cr:
      pc_pan = self.ecr_line[ibeg:iend]*(gc - 1.) 
    if self.b_field:
      bx_pan = self.bx_line[ibeg:iend] 
      by_pan = self.by_line[ibeg:iend]

    # Derived quantities
    thetav_pan = np.arctan2(vy_pan, vx_pan)
    if self.b_field:
      thetab_pan = np.arctan2(by_pan, bx_pan)

    # Save variables
    self.time = time 
    self.begin, self.end = begin, end 
    self.start, self.check = start, check

    self.file = file 
    self.ibeg, self.iend = ibeg, iend 
    self.istr, self.ichk = istr, ichk

    self.x_pan = x_pan 
    self.rho_pan = rho_pan 
    self.vx_pan = vx_pan 
    self.vy_pan = vy_pan 
    if not self.isothermal:
      self.pg_pan = pg_pan 
    if self.cr:
      self.pc_pan = pc_pan 
    if self.b_field:
      self.bx_pan = bx_pan 
      self.by_pan = by_pan 

    self.thetav_pan = thetav_pan 
    if self.b_field:
      self.thetab_pan = thetab_pan 

    self.rho1, self.rho2 = rho_pan[istr], rho_pan[ichk]
    self.vx1, self.vx2 = vx_pan[istr], vx_pan[ichk]
    self.vy1, self.vy2 = vy_pan[istr], vy_pan[ichk]
    if not self.isothermal:
      self.pg1, self.pg2 = pg_pan[istr], pg_pan[ichk]
    if self.cr:
      self.pc1, self.pc2 = pc_pan[istr], pc_pan[ichk]
    if self.b_field:
      self.bx1, self.bx2 = bx_pan[istr], bx_pan[ichk]
      self.by1, self.by2 = by_pan[istr], by_pan[ichk]
    self.thetav1, self.thetav2 = thetav_pan[istr], thetav_pan[ichk]
    if self.b_field:
      self.thetab1, self.thetab2 = thetab_pan[istr], thetab_pan[ichk]
    return 

  ##############################################################################
  # Problem specific functions
  def cloud_finder(self, link_length, search_length, temp_thres, dt, x_start=None, x_end=None, y_start=None, y_end=None, \
    video_cloud_id_list=None, savepath=None):
    file_array = self.file_array
    filename = self.filename
    cloud_future = False

    # For recording across time frames
    total_time = []
    total_cold_gas_mass = []
    total_cold_gas_mass_fraction = []
    cloud_lifespan = dict()
    cloud_life_moment = dict()
    cloud_life_size = dict()
    cloud_life_mass = dict()
    cloud_center_life_vel = dict()
    cloud_center_life_vs = dict()

    if self.isothermal:
      print('Cloud finder does not apply to isothermal EOS.')
      return

    for i, file in enumerate(file_array):
      # Extract data
      print(file_array[0] + i)
      data = ar.athdf('./' + filename + '.out1.' + format(file, '05d') + '.athdf')
      time = float('{0:f}'.format(data['Time']))
      x1v = data['x1v']
      x2v = data['x2v']
      xmesh, ymesh = np.meshgrid(x1v, x2v)
      xarg_start = np.argmin(np.abs(x1v - x_start)) if x_start != None else 0 
      xarg_end = np.argmin(np.abs(x1v - x_end)) if x_end != None else np.size(x1v) 
      yarg_start = np.argmin(np.abs(x2v - y_start)) if y_start != None else 0 
      yarg_end = np.argmin(np.abs(x2v - y_end)) if y_end != None else np.size(x2v)
      x1v = x1v[xarg_start:xarg_end]
      x2v = x2v[yarg_start:yarg_end]
      dx = x1v[1] - x1v[0] # for uniform grid
      dy = x2v[1] - x2v[0] # for uniform grid
      rho = data['rho'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      vx = data['vel1'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      vy = data['vel2'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      pg = data['press'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      vsx = data['Vc1'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      vsy = data['Vc2'][0, yarg_start:yarg_end, xarg_start:xarg_end]
      T = pg/rho
      cool_loc = np.where(T < temp_thres)
      total_cold_mass = np.sum(rho[(T<temp_thres) & (x1v>0.3)])*dx*dy 
      total_mass = np.sum(rho[x1v>0.3])*dx*dy
      cool_label = np.arange(np.size(cool_loc[0]))
      xindex_cool_loc = cool_loc[1]
      yindex_cool_loc = cool_loc[0]
      x_cool_loc = x1v[cool_loc[1]]
      y_cool_loc = x2v[cool_loc[0]]
      cloud_index = dict()
      cloud_loc = dict()
      cloud_number = 0
      total_time.append(time)
      total_cold_gas_mass.append(total_cold_mass)
      total_cold_gas_mass_fraction.append(total_cold_mass/total_mass)
      # Detect cold clouds cells and group them according to linkage
      while (np.size(cool_label) > 0):
        x_current = x_cool_loc[0]
        y_current = y_cool_loc[0]
        cloud_index_list = []
        cloud_loc_list = []
        cloud_index_list.append((xindex_cool_loc[0], yindex_cool_loc[0]))
        cloud_loc_list.append((x_current, y_current))
        cool_label = np.delete(cool_label, 0)
        xindex_cool_loc = np.delete(xindex_cool_loc, 0)
        yindex_cool_loc = np.delete(yindex_cool_loc, 0)
        x_cool_loc = np.delete(x_cool_loc, 0)
        y_cool_loc = np.delete(y_cool_loc, 0)
        link_loc = np.where(np.sqrt((x_cool_loc - x_current)**2 + (y_cool_loc - y_current)**2) < link_length)[0]
        while (np.size(link_loc) > 0):
          x_current = x_cool_loc[link_loc[0]]
          y_current = y_cool_loc[link_loc[0]]
          cloud_index_list.append((xindex_cool_loc[link_loc[0]], yindex_cool_loc[link_loc[0]]))
          cloud_loc_list.append((x_current, y_current))
          cool_label = np.delete(cool_label, link_loc[0])
          xindex_cool_loc = np.delete(xindex_cool_loc, link_loc[0])
          yindex_cool_loc = np.delete(yindex_cool_loc, link_loc[0])
          x_cool_loc = np.delete(x_cool_loc, link_loc[0])
          y_cool_loc = np.delete(y_cool_loc, link_loc[0])
          link_loc = np.delete(link_loc, 0)
          link_loc -= 1
          link_loc_add = np.where(np.sqrt((x_cool_loc - x_current)**2 + (y_cool_loc - y_current)**2) < link_length)[0]
          link_loc = np.append(link_loc, link_loc_add)
          link_loc = np.unique(link_loc)
        cloud_index[cloud_number] = cloud_index_list
        cloud_loc[cloud_number] = cloud_loc_list
        cloud_number += 1

      # Register properties of the clouds
      cloud_num_cel = dict()
      cloud_cum_cel = dict()
      cloud_mass = dict()
      cloud_locx = dict()
      cloud_locy = dict()
      cloud_velx = dict()
      cloud_vely = dict()
      cloud_vsx = dict()
      cloud_vsy = dict()
      cloud_center_vel = dict()
      cloud_center_vs = dict()
      cloud_centerx = dict()
      cloud_centery = dict()
      cloud_center = dict()
      cumcel = 0
      for key, value in cloud_index.items():
        density = []
        velocityx = []
        velocityy = []
        vstreamx = []
        vstreamy = []
        centerx = []
        centery = []
        for numcel, loca in enumerate(value):
          den = rho[loca[1], loca[0]]
          velox = vx[loca[1], loca[0]]
          veloy = vy[loca[1], loca[0]] 
          vstrx = vsx[loca[1], loca[0]]
          vstry = vsy[loca[1], loca[0]]
          cenx = x1v[loca[0]]
          ceny = x2v[loca[1]]
          density.append(den)
          velocityx.append(velox)
          velocityy.append(veloy)
          vstreamx.append(vstrx)
          vstreamy.append(vstry)
          centerx.append(cenx)
          centery.append(ceny)
        cloud_locx[key] = list(list(zip(*cloud_loc[key]))[0])
        cloud_locy[key] = list(list(zip(*cloud_loc[key]))[1])
        cloud_velx[key] = velocityx
        cloud_vely[key] = velocityy
        cloud_vsx[key] = vstreamx
        cloud_vsy[key] = vstreamy
        cloud_center_vel[key] = (np.mean(velocityx), np.mean(velocityy))
        cloud_center_vs[key] = (np.mean(vstreamx), np.mean(vstreamy))
        cloud_centerx[key] = np.mean(centerx)
        cloud_centery[key] = np.mean(centery)
        cloud_center[key] = (np.mean(centerx), np.mean(centery))
        cloud_num_cel[key] = numcel + 1
        cumcel += numcel + 1
        cloud_cum_cel[key] = cumcel
        cloud_mass[key] = np.sum(density)*dx*dy 

      # Re-label the clouds according to the predicted trajectories
      if cloud_future:
        cloud_cenx = np.fromiter(cloud_centerx.values(), dtype=float)
        cloud_ceny = np.fromiter(cloud_centery.values(), dtype=float)
        now_locx = np.array(list(itertools.chain.from_iterable(cloud_locx.values())))
        now_locy = np.array(list(itertools.chain.from_iterable(cloud_locy.values())))
        index_range = np.fromiter(cloud_cum_cel.values(), dtype=int) - 1
        link_center_predicted_to_now = dict()
        link_predicted_to_now = dict()
        # Search using predicted center position
        for key, value in cloud_center_future.items():
          future_cenx = value[0]
          future_ceny = value[1]
          index_center_nearest = np.argmin(np.sqrt((cloud_cenx - future_cenx)**2 + (cloud_ceny - future_ceny)**2))
          dist_center = np.sqrt((cloud_cenx[index_center_nearest] - future_cenx)**2 + (cloud_ceny[index_center_nearest] - future_ceny)**2)
          if (dist_center < search_length):
            link_center_predicted_to_now[key] = index_center_nearest
        # Search using predicted individual cells position
        for key, value in cloud_loc_future.items():
          label_predicted_to_now = [] 
          for j, xyloca in enumerate(cloud_loc_future[key]):
            index_nearest = np.argmin(np.sqrt((now_locx - xyloca[0])**2 + (now_locy - xyloca[1])**2))
            dist = np.sqrt((now_locx[index_nearest] - xyloca[0])**2 + (now_locy[index_nearest] - xyloca[1])**2)
            if (dist < search_length):
              cloud_label = np.argmin(np.abs(index_range - index_nearest))
              cloud_label = cloud_label + 1 if index_range[cloud_label] < index_nearest else cloud_label
              label_predicted_to_now.append(cloud_label)
          if np.size(label_predicted_to_now) > 0:
            mark, num_mark = stats.mode(label_predicted_to_now)  
            # link_predicted_to_now[key] = mark[0] if num_mark[0] > 1 else link_center_predicted_to_now[key]
            link_predicted_to_now[key] = mark[0]
        # Merge keys with repeated values
        repeat = dict()
        value_index = np.unique(np.fromiter(link_predicted_to_now.values(), dtype=int))
        for val in value_index:
          repeat_list = [k for k, v in link_predicted_to_now.items() if v == val]
          repeat[repeat_list[0]] = val
        link_predicted_to_now = dict(repeat)
        self.link_center_predicted_to_now = link_center_predicted_to_now
        self.link_predicted_to_now = link_predicted_to_now

        # Add new clouds
        index_cloud = dict()
        loc_cloud = dict()
        num_cel_cloud = dict()
        mass_cloud = dict()
        locx_cloud = dict()
        locy_cloud = dict()
        velx_cloud = dict()
        vely_cloud = dict()
        vsx_cloud = dict()
        vsy_cloud = dict()
        center_vel_cloud = dict()
        center_vs_cloud = dict()
        centerx_cloud = dict()
        centery_cloud = dict()
        center_cloud = dict()
        cloud_center_vel_real = dict()
        new_start_label = np.amax(np.fromiter(link_predicted_to_now.keys(), dtype=int)) + 1
        remain_cloud_label = np.delete(np.fromiter(cloud_index.keys(), dtype=int), np.fromiter(link_predicted_to_now.values(), dtype=int))
        for key, value in link_predicted_to_now.items():
          index_cloud[key] = cloud_index[value]
          loc_cloud[key] = cloud_loc[value]
          num_cel_cloud[key] = cloud_num_cel[value]
          mass_cloud[key] = cloud_mass[value]
          locx_cloud[key] = cloud_locx[value]
          locy_cloud[key] = cloud_locy[value]
          velx_cloud[key] = cloud_velx[value]
          vely_cloud[key] = cloud_vely[value]
          vsx_cloud[key] = cloud_vsx[value]
          vsy_cloud[key] = cloud_vsy[value]
          center_vel_cloud[key] = cloud_center_vel[value]
          center_vs_cloud[key] = cloud_center_vs[value]
          centerx_cloud[key] = cloud_centerx[value]
          centery_cloud[key] = cloud_centery[value]
          center_cloud[key] = cloud_center[value]
          # Calculate actual cloud velocity across frames
          cloud_center_velx_real = (centerx_cloud[key] - cloud_center_prev[key][0])/dt 
          cloud_center_vely_real = (centery_cloud[key] - cloud_center_prev[key][1])/dt 
          cloud_center_vel_real[key] = (cloud_center_velx_real, cloud_center_vely_real)
        if np.size(remain_cloud_label) > 0:
          new_cloud_label = np.arange(np.size(remain_cloud_label))
          for j, lab in enumerate(new_cloud_label):
            index_cloud[new_start_label+lab] = cloud_index[remain_cloud_label[j]]
            loc_cloud[new_start_label+lab] = cloud_loc[remain_cloud_label[j]]
            num_cel_cloud[new_start_label+lab] = cloud_num_cel[remain_cloud_label[j]]
            mass_cloud[new_start_label+lab] = cloud_mass[remain_cloud_label[j]]
            locx_cloud[new_start_label+lab] = cloud_locx[remain_cloud_label[j]]
            locy_cloud[new_start_label+lab] = cloud_locy[remain_cloud_label[j]]
            velx_cloud[new_start_label+lab] = cloud_velx[remain_cloud_label[j]]
            vely_cloud[new_start_label+lab] = cloud_vely[remain_cloud_label[j]]
            center_vel_cloud[new_start_label+lab] = cloud_center_vel[remain_cloud_label[j]]
            centerx_cloud[new_start_label+lab] = cloud_centerx[remain_cloud_label[j]]
            centery_cloud[new_start_label+lab] = cloud_centery[remain_cloud_label[j]]
            center_cloud[new_start_label+lab] = cloud_center[remain_cloud_label[j]]
        cloud_index = dict(index_cloud)
        cloud_num_cel = dict(num_cel_cloud)
        cloud_mass = dict(mass_cloud)
        cloud_loc = dict(loc_cloud)
        cloud_locx = dict(locx_cloud)
        cloud_locy = dict(locy_cloud)
        cloud_velx = dict(velx_cloud)
        cloud_vely = dict(vely_cloud)
        cloud_vsx = dict(vsx_cloud)
        cloud_vsy = dict(vsy_cloud)
        cloud_center_vel = dict(center_vel_cloud)
        cloud_center_vs = dict(center_vs_cloud)
        cloud_centerx = dict(centerx_cloud)
        cloud_centery = dict(centery_cloud)
        cloud_center = dict(center_cloud)
        self.cloud_center_vel_real = cloud_center_vel_real

        # Record number of frames each cloud has persisted so far
        key_so_far = cloud_lifespan.keys()
        for key in link_predicted_to_now.keys():
          if key in key_so_far:
            cloud_lifespan[key] += dt
            cloud_life_moment[key].append(time)
            cloud_life_size[key].append(cloud_num_cel[key]*dx*dy)
            cloud_life_mass[key].append(cloud_mass[key])
            cloud_center_life_vel[key].append(cloud_center_vel_real[key])
            cloud_center_life_vs[key].append(cloud_center_vs[key])
          else:
            cloud_lifespan[key] = dt
            cloud_life_moment[key] = [time]
            cloud_life_size[key] = [cloud_num_cel[key]*dx*dy]
            cloud_life_mass[key] = [cloud_mass[key]]
            cloud_center_life_vel[key] = [cloud_center_vel_real[key]]
            cloud_center_life_vs[key] = [cloud_center_vs[key]]

      if (video_cloud_id_list != None):
        # Specify the vertices of the bounding boxes (xmin, xmax, width, height)
        cloud_bounding_box = dict() 
        xmin, xmax = x1v[0] - 0.5*dx, x1v[-1] + 0.5*dx
        ymin, ymax = x2v[0] - 0.5*dy, x2v[-1] + 0.5*dy
        # Check if cloud id is in list
        cloud_present = [k for k in video_cloud_id_list if k in list(cloud_index.keys())]
        for key in cloud_present:
          xloc = np.array(list(zip(*cloud_loc[key]))[0])
          yloc = np.array(list(zip(*cloud_loc[key]))[1])
          xmin_loc, xmax_loc = np.amin(xloc), np.amax(xloc)
          ymin_loc, ymax_loc = np.amin(yloc), np.amax(yloc)
          xmin_bound = xmin_loc - link_length if (xmin_loc > link_length + xmin) else xmin
          xmax_bound = xmax_loc + link_length if (xmax_loc + link_length < xmax) else xmax
          ymin_bound = ymin_loc - link_length if (ymin_loc > link_length + ymin) else ymin
          ymax_bound = ymax_loc + link_length if (ymax_loc + link_length < ymax) else ymax 
          cloud_bounding_box[key] = (xmin_bound, ymin_bound, (xmax_bound - xmin_bound), (ymax_bound - ymin_bound))

        # Plot temperature plot with bounding box
        fig1 = plt.figure()
        ax1 = fig1.add_subplot(111)

        img1 = ax1.imshow(np.log10(T), cmap='bwr', aspect='auto', origin='lower', extent=(x1v[0], x1v[-1], x2v[0], x2v[-1]))
        bounding_box = [Rectangle((v[0], v[1]), v[2], v[3]) for v in cloud_bounding_box.values()]
        bb = PatchCollection(bounding_box, facecolor='none', edgecolor='r', linewidth=1, label=list(cloud_bounding_box.keys()))
        ax1.add_collection(bb)
        for key in cloud_present:
          ax1.text(cloud_bounding_box[key][0], cloud_bounding_box[key][1], str(key))

        divider = make_axes_locatable(ax1)
        cax = divider.append_axes('right', size="5%", pad=0.0)
        fig1.colorbar(img1, ax=ax1, label='$\\mathrm{log}(T)$', cax=cax)

        props = dict(boxstyle='round', facecolor='wheat')
        ax1.text(0.8, 0.95, 't={:.2f}'.format(time), transform=ax1.transAxes, bbox=props)
        ax1.set_xlabel('$x$')
        ax1.set_ylabel('$y$')
        ax1.xaxis.set_minor_locator(AutoMinorLocator())
        ax1.yaxis.set_minor_locator(AutoMinorLocator())

        fig1.tight_layout()
        addpath = 'track' + str(i)
        if savepath != None:
          fig1.savefig(savepath + addpath, dpi=300)
        else:
          plt.show()

        plt.close('all')

      # Predict future location of cloud and save current location as previous
      if len(cloud_index.keys()) > 0:
        cloud_future = True
        cloud_center_future = dict()
        cloud_center_prev = dict()
        cloud_loc_futurex = dict()
        cloud_loc_futurey = dict()
        cloud_loc_future = dict()
        # Predict future location of cloud center
        for key, value in cloud_center.items():
          centx = value[0]
          centy = value[1]
          vel_centerx = cloud_center_vel[key][0]
          vel_centery = cloud_center_vel[key][1]
          cen_futurex = centx + vel_centerx*dt 
          cen_futurey = centy + vel_centery*dt 
          cloud_center_future[key] = (cen_futurex, cen_futurey)
          cloud_center_prev[key] = (centx, centy)
        # Predict future location of individual cloud cells
        for key, value in cloud_loc.items():
          xind = np.array(list(zip(*value))[0])
          yind = np.array(list(zip(*value))[1])
          velx = np.array(cloud_velx[key])
          vely = np.array(cloud_vely[key])
          xfuture = list(xind + velx*dt)
          yfuture = list(yind + vely*dt) 
          cloud_loc_futurex[key] = xfuture
          cloud_loc_futurey[key] = yfuture
          cloud_loc_future[key] = list(zip(xfuture, yfuture))

        self.cloud_center_future = cloud_center_future
        self.cloud_center_prev = cloud_center_prev
        self.cloud_loc_futurex = cloud_loc_futurex 
        self.cloud_loc_futurey = cloud_loc_futurey
        self.cloud_loc_future = cloud_loc_future
      else:
        cloud_future = False

      # Store data regarding present frame
      self.link_length = link_length 
      self.temp_thres = temp_thres 
      self.x_start = x1v[0] if x_start == None else x_start
      self.x_end = x1v[-1] if x_end == None else x_end
      self.y_start = x2v[0] if y_start == None else y_start
      self.y_end = x2v[-1] if y_end == None else y_end
      self.x1v = x1v
      self.x2v = x2v
      self.cloud_index = cloud_index
      self.cloud_locx = cloud_locx 
      self.cloud_locy = cloud_locy
      self.cloud_loc = cloud_loc
      self.cloud_velx = cloud_velx
      self.cloud_vely = cloud_vely
      self.cloud_vsx = cloud_velx
      self.cloud_vsy = cloud_vely
      self.cloud_center_vel = cloud_center_vel
      self.cloud_center_vs = cloud_center_vs
      self.cloud_centerx = cloud_centerx
      self.cloud_centery = cloud_centery
      self.cloud_center = cloud_center
      self.cloud_num_cel = cloud_num_cel
      self.cloud_cum_cel = cloud_cum_cel

      # Store data following clouds' life
      self.total_time = total_time
      self.total_cold_gas_mass = total_cold_gas_mass
      self.total_cold_gas_mass_fraction = total_cold_gas_mass_fraction
      self.cloud_lifespan = cloud_lifespan
      self.cloud_life_moment = cloud_life_moment
      self.cloud_life_size = cloud_life_size
      self.cloud_center_life_vel = cloud_center_life_vel
      self.cloud_center_life_vs = cloud_center_life_vs

    return 

# End of class

#######################################################
inputfile = 'athinput.cr_thermal_2d_2'
file_array = np.array([667]) 

selected_file = file_array[0]

one = Plot2d(inputfile, file_array)
fig = one.plot(selected_file, log_den=True, log_therm=True, discrepant=None, aspects='auto')
# fig = one.plot(selected_file, log_den=True, log_therm=False, discrepant=[file_array[0], file_array[1]], aspects='equal')
fig[0].savefig('./rho.png', dpi=300)
fig[1].savefig('./v.png', dpi=300)
if not one.isothermal:
  fig[2].savefig('./pg.png', dpi=300)
  fig[3].savefig('./T.png', dpi=300)
if one.cr:
  fig[4].savefig('./pc.png', dpi=300)
plt.show()
plt.close('all')

# proj = one.project1d(x_or_y='x', log_indep=False, log_dep=True)
# proj.savefig('./project1d.png', dpi=300)
# plt.show()
# plt.close('all')

line = one.line(selected_file, x_or_y='x', quartile=0.7, log_indep=False, log_dep=True) 
line.savefig('./line.png', dpi=300)
plt.show()
plt.close('all')

# one.pan1d()

#############################
# Video

# comm = MPI.COMM_WORLD
# size = comm.Get_size()
# rank = comm.Get_rank()

# file_start = 0
# file_end = 106

# total_num_file = file_end - file_start 
# each = total_num_file//size

# video_array = np.arange(file_start + rank*each, file_start + (rank+1)*each)
# video = Plot2d(inputfile, video_array, make_video=True)
# video_path = '/Users/tsunhinnavintsung/Workspace/Codes/workspace/1dcr_v2_1/cr_thermal/results/sims/output/video/'
# video.make_video(video_path, log_den=True, log_therm=True, log_pc=True, log_beta=True, \
#   x_start=0., x_end=None, y_start=None, y_end=None, aspects='equal')

#############################
# Line video

# comm = MPI.COMM_WORLD
# size = comm.Get_size()
# rank = comm.Get_rank()

# file_start = 659
# file_end = 659

# total_num_file = file_end - file_start 
# each = total_num_file//size

# line_array = np.arange(file_start + rank*each, file_start + (rank+1)*each)
# line_array = np.array([0, 659])
# line = Plot2d(inputfile, line_array, make_line_video=True)
# line_path = '/Users/tsunhinnavintsung/Workspace/Codes/workspace/1dcr_v2_1/cr_thermal/results/sims/output/video/'
# line.make_line_video(line_path, x_or_y='x', quartile=0.5, \
#   log_den=False, log_therm=False, log_pc=False, log_beta=False,)

#############################
# Cloud finder

# comm = MPI.COMM_WORLD
# size = comm.Get_size()
# rank = comm.Get_rank()

# file_start = 0
# file_end = 100

# total_num_file = file_end - file_start 
# each = total_num_file//size

# cloud_finder_array = np.arange(file_start + rank*each, file_start + (rank+1)*each)
# # cloud_finder_array = np.array([182])
# # cloud_finder_array2 = np.array([85, 86])
# # cloud_finder_array3 = np.array([85, 86, 87])
# cloud_finder = Plot2d(inputfile, cloud_finder_array, cloud_find=True)
# # cloud_finder2 = Plot2d(inputfile, cloud_finder_array2, cloud_find=True)s
# # cloud_finder3 = Plot2d(inputfile, cloud_finder_array3, cloud_find=True)

# # Set finder parameters
# link_length = 2.*(cloud_finder.x1max - cloud_finder.x1min)/cloud_finder.nx1 
# sch_length = 2.*(cloud_finder.x1max - cloud_finder.x1min)/cloud_finder.nx2
# temp_thres = 0.03
# dt = 0.1

# video_id_list = [89, 179, 214, 326, 336, 346]

# savepath = '../../output/video/'

# cloud_finder.cloud_finder(link_length, sch_length, temp_thres, dt, x_start=None, x_end=None, y_start=None, y_end=None, video_cloud_id_list=video_id_list, savepath=savepath)
# cloud_finder.cloud_finder(link_length, sch_length, temp_thres, dt, x_start=None, x_end=None, y_start=None, y_end=None)
# cloud_finder2.cloud_finder(link_length, sch_length, temp_thres, dt, x_start=None, x_end=None, y_start=None, y_end=None, video_cloud_id_list=video_id_list)
# cloud_finder3.cloud_finder(link_length, sch_length, temp_thres, dt, x_start=None, x_end=None, y_start=None, y_end=None)

# # Display the grouped clouds
# group = np.ones((cloud_finder.nx2, cloud_finder.nx1, 3))
# group_future = np.ones((cloud_finder.nx2, cloud_finder.nx1, 3))
# group_cen_future = np.ones((cloud_finder.nx2, cloud_finder.nx1, 3))
# for key, value in cloud_finder.cloud_index.items():
#   col = np.random.random(3)
#   x_fut = np.array(list(zip(*cloud_finder.cloud_loc_future[key]))[0])
#   y_fut = np.array(list(zip(*cloud_finder.cloud_loc_future[key]))[1])
#   for i in range(len(x_fut)):
#     indx = np.argmin(np.abs(cloud_finder.x1v - x_fut[i]))
#     indy = np.argmin(np.abs(cloud_finder.x2v - y_fut[i]))
#     group_future[indy, indx, :] = col
#   x_cen = cloud_finder.cloud_center_future[key][0]
#   y_cen = cloud_finder.cloud_center_future[key][1]
#   x_grid = np.argmin(np.abs(cloud_finder.x1v - x_cen))
#   y_grid = np.argmin(np.abs(cloud_finder.x2v - y_cen))
#   group_cen_future[y_grid, x_grid, :] = col
#   for i, ind in enumerate(value):
#     group[ind[1], ind[0], :] = col
  
# group2 = np.ones((cloud_finder2.nx2, cloud_finder2.nx1, 3))
# for key, value in cloud_finder2.cloud_index.items():
#   col = np.random.random(3)
#   for i, ind in enumerate(value):
#     group2[ind[1], ind[0], :] = col

# group3 = np.ones((cloud_finder3.nx2, cloud_finder3.nx1, 3))
# for key, value in cloud_finder3.cloud_index.items():
#   col = np.random.random(3)
#   for i, ind in enumerate(value):
#     group3[ind[1], ind[0], :] = col

# fig = plt.figure() 
# ax = fig.add_subplot(111)

# ax.imshow(group, aspect='auto', origin='lower', \
#   extent=(cloud_finder.x_start, cloud_finder.x_end, cloud_finder.y_start, cloud_finder.y_end))
# ax.imshow(group_cen_future, aspect='auto', alpha=0.3, origin='lower', \
#   extent=(cloud_finder.x_start, cloud_finder.x_end, cloud_finder.y_start, cloud_finder.y_end))
# ax.imshow(group_future, aspect='auto', alpha=0.5, origin='lower', \
#   extent=(cloud_finder.x_start, cloud_finder.x_end, cloud_finder.y_start, cloud_finder.y_end))
# ax.imshow(group2, aspect='auto', alpha=0.5, origin='lower', \
#   extent=(cloud_finder2.x_start, cloud_finder2.x_end, cloud_finder2.y_start, cloud_finder2.y_end))
# ax.imshow(group3, aspect='auto', alpha=0.5, origin='lower', \
#   extent=(cloud_finder3.x_start, cloud_finder3.x_end, cloud_finder3.y_start, cloud_finder3.y_end))

# for cloud_lab in cloud_finder.cloud_index.keys():
#   ax.text(cloud_finder.cloud_centerx[cloud_lab], cloud_finder.cloud_centery[cloud_lab], str(cloud_lab), fontsize=5, color='r')
# for cloud_lab in cloud_finder2.cloud_index.keys():
#   ax.text(cloud_finder2.cloud_centerx[cloud_lab], cloud_finder2.cloud_centery[cloud_lab], str(cloud_lab), fontsize=5, color='b')
# for cloud_lab in cloud_finder3.cloud_index.keys():
#   ax.text(cloud_finder3.cloud_centerx[cloud_lab], cloud_finder3.cloud_centery[cloud_lab], str(cloud_lab), fontsize=5, color='g')

# fig.tight_layout()
# fig.savefig('./cloud_group.png', dpi=300)

# plt.show()
# plt.close('all')

#############################
# Derived plotting

# # Plot of drho_rms against time
# dt = 0.01
# hist_files_all = [ \
#   'a1b10k_01tc1nu3res256c200half',
#   'a1b10k_01tc1nu3res512c200',
#   'a1b10k_01tc1nu3res512c200magic',
#   'a1b10k_01tc1nu3res512c400',
#   'a1b10k_01tc1nu3res256c1001d',
#   'a1b10k_01tc1nu3res256c2001d',
#   'a1b10k_01tc1nu3res256c4001d',
#   'a1b10k_01tc1nu3res256c8001d',
#   'a1b10k_01tc1nu3res512c1001d',
#   'a1b10k_01tc1nu3res512c2001d',
#   'a1b10k_01tc1nu3res512c4001d',
#   'a1b10k_01tc1nu3res512c8001d',
#   'a1b10k_01tc1nu3res512c10001d',
#   'a1b10k_01tc1nu3res512c16001d',
#   'a1b10k_01tc1nu3res1024c1001d',
#   'a1b10k_01tc1nu3res1024c4001d',
#   'a1b10k_01tc1nu3res1024c8001d',
#   'a1b10k_01tc1nu3res1024c800nmax4001d',
#   'a1b10k_01tc1nu3res1024c10001d',
#   'a1b10k_01tc1nu3res1024c16001d',
#   'a1b10k_01tc1nu3res1024c32001d',
#   'a1b10k_01tc1nu3res2048c400nmax2001d',
#   'a1b10k_01tc1nu3res2048c400nmax4001d',
#   'a1b1000k_01tc1nu5res1024c2001d',
#   'a1b100000k_001tc1nu6res4096c200',
#   'a1b1000000k_01tc1nu6res256c2001d',
#   'a1b1000000k_01tc1nu6res1024c4001d',
#   ]

# hist_files = [ \
#   # 'a1b10k_01tc1nu3res256c200half',
#   # 'a1b10k_01tc1nu3res512c200',
#   # 'a1b10k_01tc1nu3res512c200magic',
#   # 'a1b10k_01tc1nu3res512c400',
#   # 'a1b10k_01tc1nu3res256c1001d',
#   # 'a1b10k_01tc1nu3res256c2001d',
#   # 'a1b10k_01tc1nu3res256c4001d',
#   # 'a1b10k_01tc1nu3res256c8001d',
#   # 'a1b10k_01tc1nu3res512c1001d',
#   # 'a1b10k_01tc1nu3res512c2001d',
#   # 'a1b10k_01tc1nu3res512c4001d',
#   # 'a1b10k_01tc1nu3res512c8001d',
#   # 'a1b10k_01tc1nu3res512c10001d',
#   # 'a1b10k_01tc1nu3res512c16001d',
#   'a1b10k_01tc1nu3res1024c1001d',
#   'a1b10k_01tc1nu3res1024c4001d',
#   'a1b10k_01tc1nu3res1024c8001d',
#   'a1b10k_01tc1nu3res1024c800nmax4001d',
#   'a1b10k_01tc1nu3res1024c10001d',
#   'a1b10k_01tc1nu3res1024c16001d',
#   'a1b10k_01tc1nu3res1024c32001d',
#   'a1b10k_01tc1nu3res2048c400nmax2001d',
#   'a1b10k_01tc1nu3res2048c400nmax4001d',
#   'a1b1000k_01tc1nu5res1024c2001d',
#   'a1b100000k_001tc1nu6res4096c200',
#   'a1b1000000k_01tc1nu6res256c2001d',
#   'a1b1000000k_01tc1nu6res1024c4001d',
#   ]

# drho_rms = dict()
# time = dict()

# for i, filename in enumerate(hist_files):
#   # Extract drho_rms from column 17
#   drho_rms[filename] = np.sqrt(np.loadtxt('./history/'+filename+'.hst', usecols=17))
#   time[filename] = np.array([i*dt for i in range(np.size(drho_rms[filename]))])

# # Plot drho_rms for different runs
# fig1 = plt.figure()
# ax1 = fig1.add_subplot(111)

# for i, filename in enumerate(hist_files):
#   ax1.semilogy(time[filename], drho_rms[filename], label=filename)

# ax1.margins(x=0)
# # ax1.set_xlim(0, 6.68)
# ax1.legend(frameon=False)
# ax1.set_xlabel('$t$')
# ax1.set_ylabel('$\\langle\\delta\\rho/\\rho\\rangle_{\\mathrm{rms}}$')
# ax1.xaxis.set_minor_locator(AutoMinorLocator())

# fig1.tight_layout()
# fig1.savefig('./drho_rms.png', dpi=300)
# plt.show()

# plt.close()


#############################
# Publication plots
