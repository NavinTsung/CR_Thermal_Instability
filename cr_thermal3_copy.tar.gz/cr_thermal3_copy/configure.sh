#!/bin/bash
python configure.py --prob cr_thermal2d_2 -cr -b -hdf5 -mpi --hdf5_path /usr/local/Cellar/hdf5-parallel/1.12.0 --include /Users/tsunhinnavintsung/Workspace/Codes/cpp_lib/eigen/eigen-3.3.9 --include /Users/tsunhinnavintsung/Workspace/Codes/cpp_lib/boost/boost_1_76_0 
